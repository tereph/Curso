<?php
include_once '../conexion/conexion.php';
    $query = 'call repositoriocio.sp_nuevoUsuario(0,"' . $_POST['nu'] . '","' . $_POST['apa'] . '", "' . $_POST['ama'] . '","' . $_POST['usu'] . '", "' . $_POST['contra'] . '",' . $_POST['idEmp'] . ',' . $_POST['rol'] . ')';
    mysql_query($query);
    $consulta = "select correo from empresa where idEmpresa=" . $_POST['idEmp'] . "";
    //mysql_query($consulta);    
    $res = mysql_query($consulta) or die('Consulta fallida: ' . mysql_error());
    $coo;
    while ($fi = mysql_fetch_assoc($res)) {
        $coo = $fi['correo'];
    }    
    $mail = "<html>"
            . "<head>Sistema de Consulta de Facturas y Cuentas por Cobrar</head>"
            . "<body><p>Hola " . $_POST['nu'] . " " . $_POST['apa'] . " ha sido registrado en el Sistema de Consulta de Facturas y Cuentas por Cobrar.</p>"
            . "<p>Lo primero que debes hacer es activar tu cuenta ingresando a la siguiente liga <a href='http://sw2.cio.mx/mario/repositorioFacturas/index.php'>Sistema de Consulta de Facturas y Cuentas por Cobrar</a> con el Usuario: " . $_POST['usu'] . " y la Clave de Acceso: <span style='color:#1e3664'>" . $_POST['contra'] . "</span></p></body></html>";
//Titulo
    $titulo = "Sistema de Consulta de Facturas";
//cabecera
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
//dirección del remitente 
    $headers .= "From: Sistema de Facturas < terep@cio.mx.com >\r\n";
//Enviamos el mensaje a tu_dirección_email 
    $bool = mail("$coo", $titulo, $mail, $headers);
    if ($bool) {
        echo "Mensaje enviado";
    } else {
        echo "Mensaje no enviado";
    }