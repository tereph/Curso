<?php
include_once '../conexion/conexion.php';
session_start();
if (!isset($_SESSION['loggedin'])) {
    //Esto redirecciona al index
    header('Location: index.php');
}
if (isset($_POST['Salir']) and $_POST['Salir'] == 'Salir') {
    session_destroy();
    header('Location: ../index.php');
} else
if (isset($_POST['NuevaEmpresa'])) {
    header('Location: ../usuarios/formularioEmpresa.php');
} else
if (isset($_POST['NuevoUsuario'])) {
    //header('Location: ../usuarios/formulario.php');
    header('Location: ../usuarios/formularioEmpresa.php');
}
?>
<!DOCTYPE html>
<html>
    <head>
        <!-- <link href="../plantilla/dataTables.jqueryui.css" rel="stylesheet" type="text/css"/>
         <link href="../plantilla/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <!--<link href="../plantilla/jquery.dataTables.css" rel="stylesheet" type="text/css"/>-->
        <link href="../jqueryui/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="../growl/jquery.growl.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/estiloBotones.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/estiloTablas.css" rel="stylesheet" type="text/css"/>
        <!-- ESTILO PARA LOS BOTONES-->
        <link href="fonts/font-awesome-4.2.0/fonts/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/buttons.css" rel="stylesheet" type="text/css"/>

        <script src="../js/jquery-1.7.2.min.js" type="text/javascript"></script>
        <script src="../plantilla/buttons.js" type="text/javascript"></script>
        <!-- FIN DE LOS ESTILOS DE LOS BOTONES-->

        <!-- ESTILO PARA LAS CAJAS DE TEXTO -->
        <link href="css/normalize.css" rel="stylesheet" type="text/css"/>
        
        <link href="css/demoEstiloCajas.css" rel="stylesheet" type="text/css"/>
        <link href="css/estiloCajas.css" rel="stylesheet" type="text/css"/>
        <!--<link href="fonts/font-awesome-4.2.0/fonts/font-awesome.min.css" rel="stylesheet" type="text/css"/>-->
        <!-- FIN DEL ESTILO PARA LAS CAJAS DE TEXTO -->

        <!--ESTILO PARA LINKS-->
        <link href="../plantilla/css/normalize.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/css/demo.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/css/component.css" rel="stylesheet" type="text/css"/>
        <script src="../plantilla/js/modernizr.custom.js" type="text/javascript"></script>
        <!-- FIN DE LOS ESTILOS PARA LINKS-->
        <script src="../jqueryui/jquery-ui.js" type="text/javascript"></script>
        <script src="../growl/jquery.growl.js" type="text/javascript"></script>
        <script src="../js/usuarios.js" type="text/javascript"></script>
        <script src="../js/empresas.js" type="text/javascript"></script>
        <style type="text/css">
            img{
                transition: 1s;
                -moz-transition: 1s; /* Firefox 4 */
                -webkit-transition: 1s; /* Safari and Chrome */
                -o-transition: 1s; /* Opera */
            }
        </style>
    </head>
    <body style="background-image: url('../img/fondo.jpg');background-repeat: no-repeat">
        <?php
        include_once '../plantilla/menu.php';
        ?>
        <div id="accordion" style="width: 90%;margin-left: 5%;margin-bottom: 30px;margin-top: 30px;">
            <h3>Usuarios registrados</h3>
            <div>
                    <div style="float: right;margin-bottom: 20px"> 
                        <button id="btnNuevoCliente" type="button" class="button button-rounded button-flat-primary button-jumbo" style="height: 51.2px;"><span class="fa fa-user" style="margin-right: 10px;"></span>Nuevo Usuario</button>
                        <!--<a href="../usuarios/formulario.php" class="button button-rounded button-flat-primary button-jumbo"><i class="fa fa-user" style="margin-right: 10px;"></i>Nuevo Usuario</a>-->
                    </div>
                <div style="font-size: 16px;" id="tblUsuarioRegistrados"></div>
            </div>
            <h3>Empresas registradas</h3>
            <div>
                <form method="post">
                    <div style="float: right;margin-bottom: 20px"> 
                        <!--<button id="btnNuevaEmpresa" name="NuevaEmpresa" value="NuevaEmpresa" type="submit" class="info">Nueva Empresa</button>-->
                        <button class="button button-rounded button-flat-primary button-jumbo" id="btnNuevaEmpresa" name="NuevaEmpresa" value="NuevaEmpresa" type="submit" style="height: 51.2px;"><span class="fa fa-building" style="margin-right: 10px;"></span>Nueva Empresa</button>
                    </div>
                </form>
                <div id="tblUsuarioEmpresas" style="font-size: 16px;">
                </div>
            </div>

        </div>
        <div id="dialogUsuarios" style="background-color: #f2f4f6;width: 62%;">
            <form method="post" id="frmUsuarios">
                <input type="hidden" name="idUsuario" id="txtIdUsuario" class="txt">
                <div id="lblMensajeError" style="background-color: #ff8080;font-size: 20px;text-align: center;height: 50px;margin: 1rem;padding: 1rem;">Este usuario no se puede modificar ya que no esta activo</div>
                <section class="content" style="font-size: 110%;">
                    <!--<label>Nombre</label>
                    <input type="text" id="txtNombreUsuario" name="nu" class="txt" onkeypress="quitarError('txtNombreUsuario');">    
                    -->
                    <span class="input input--hideo">
                        <input type="text" id="txtNombreUsuario" name="nu" class="input__field input__field--hideo" onfocus="quitarError('txtNombreUsuario');" title="Nombre">    
                        <label class="input__label input__label--hideo" for="txtNombreUsuario">
                            <i class="fa fa-fw fa-user icon icon--hideo"></i>
                            <span class="input__label-content input__label-content--hideo">Nombre</span>
                        </label>
                    </span>
                    <!--<label>Apellido Paterno</label>
                    <input type="text" id="txtApellidoPaterno" name="apa" class="txt" onkeypress="quitarError('txtApellidoPaterno');">    -->
                    <span class="input input--hideo">
                        <input type="text" id="txtApellidoPaterno" name="apa" class="input__field input__field--hideo" onfocus="quitarError('txtApellidoPaterno');" title="Apellido Paterno">    
                        <label class="input__label input__label--hideo" for="txtApellidoPaterno">
                            <i class="fa fa-fa fa-user icon icon--hideo"></i>
                            <span class="input__label-content input__label-content--hideo">Apellido Paterno</span>
                        </label>
                    </span>
                    <!--<label>Apellido Materno</label>
                    <input type="text" id="txtApellidoMaterno" name="ama" class="txt" onkeypress="quitarError('txtApellidoMaterno');">    -->
                    <span class="input input--hideo">
                        <input type="text" id="txtApellidoMaterno" name="ama" class="input__field input__field--hideo" onfocus="quitarError('txtApellidoMaterno');" title="Apellido Materno">    
                        <label class="input__label input__label--hideo" for="txtApellidoMaterno">
                            <i class="fa fa-fa fa-user icon icon--hideo"></i>
                            <span class="input__label-content input__label-content--hideo">Apellido Materno</span>
                        </label>
                    </span>
                    <!--<label>Usuario</label>
                    <input type="text" name="usu" id="txtUsuario" class="txt">-->
                    <span class="input input--hideo">
                        <input type="text" id="txtUsuario" name="usu" placeholder="Usuario" class="input__field input__field--hideo" onfocus="quitarError('txtUsuario');" readonly="true" title="Usuario">    
                        <label class="input__label input__label--hideo" for="txtUsuario">
                            <i class="fa fa-fa fa-male icon icon--hideo"></i>
                            <span class="input__label-content input__label-content--hideo">Usuario</span>
                        </label>
                    </span>

                    <!--<label>Contraseña</label>
                    <input type="password" id="txtContrasena" name="contra" class="txt">-->
                    <span class="input input--hideo">
                        <input type="password" id="txtContrasena" name="contra" placeholder="Contrasena" class="input__field input__field--hideo" onfocus="quitarError('txtContrasena');">    
                        <label class="input__label input__label--hideo" for="txtContrasena">
                            <i class="fa fa-fa fa-unlock-alt icon icon--hideo"></i>
                            <span class="input__label-content input__label-content--hideo">Contrasena</span>
                        </label>
                    </span>
                </section>
            </form>
            <div style="float: right;margin-bottom: 20px;margin-top: 30px;margin-right: 20px;">
                <button style="float: right;margin-left: 15px" type="button" name="Guardar" id="btnGuardarUsuario" class="button button-rounded button-flat-primary button-large"> <span class="fa fa-save" style="margin-right: 10px;"></span>Guardar</button>
            <button style="float: right;" type="button" id="btnCancelarUsuario" class="button button-rounded button-flat-caution button-large"> <span class="fa fa-close" style="margin-right: 10px;"></span>Cancelar</button>
            </div>
            
        </div>
        <div id="dialogEliminarEmpresa" style="background-color: #f2f4f6;width: 30%;">
            <div style="font-size: 20px">
                <label id="lblEliminarEmpresa"></label>
            </div>
            <div style="float: right;margin-bottom: 20px;margin-top: 20px;">
                <button id="btnCerrar" class="button button-rounded button-flat-caution button-large"><span class="fa fa-close" style="margin-right: 10px;"></span>Aceptar</button>
                <button id="btnSiEliEmp" onclick="eliminarEmpresa();" class="button button-rounded button-flat-action button-large" style="margin-left: 10px;"><span class="fa fa-check" style="margin-right: 10px;"></span>Si</button>
            </div>
        </div>
        <div id="dialogEmpresa" style="background-color: #f2f4f6;">
            <form method="post" id="frmEditarEmpresa">
                <!--<label>Empresa</label>
                <input type="text" id="txtEmpresa" name="emp" class="txt" onkeypress="quitarError('txtEmpresa');" readonly="true">-->
                <section class="content" style="font-size: 110%">
                <span class="input input--hideo">
                    <input type="text" id="txtEmpresa" name="emp" class="input__field input__field--hideo" onfocus="quitarError('txtEmpresa');" title="Empresa">
                    <label class="input__label input__label--hideo" for="txtEmpresa">
                        <i class="fa fa-fw fa-institution icon icon--hideo"></i>
                        <span class="input__label-content input__label-content--hideo">Empresa</span>
                    </label>
                </span>
                <!--<label>Correo</label>
                <input type="text" id="txtCorreo" name="email" class="txt" onkeypress="quitarError('txtCorreo');">    -->
                <span class="input input--hideo">
                    <input type="text" id="txtCorreo" name="email" class="input__field input__field--hideo" onfocus="quitarError('txtCorreo');" title="Correo">
                    <label class="input__label input__label--hideo" for="txtCorreo">
                        <i class="fa fa-fw fa-envelope-o icon icon--hideo"></i>
                        <span class="input__label-content input__label-content--hideo">Correo</span>
                    </label>
                </span>
                <!--<label>Teléfono</label>
                <input type="text" id="txtTelefono" name="tel" class="txt" onkeypress="quitarError('txtTelefono');">-->
                <span class="input input--hideo">
                    <input type="text" id="txtTelefono" name="email" class="input__field input__field--hideo" onfocus="quitarError('txtTelefono');" title="Telefono">
                    <label class="input__label input__label--hideo" for="txtTelefono">
                        <i class="fa fa-fw fa-fax icon icon--hideo"></i>
                        <span class="input__label-content input__label-content--hideo">Telefono</span>
                    </label>
                </span>
                </section>
            </form>
            <section style="float: right;margin-right: 6%">
                <button id="btnCancelarEmpresa" class="button button-rounded button-flat-caution button-large" style="margin-right: 25px;"> <span class="fa fa-close" style="margin-right: 10px;"></span>Cancelar</button>
                <button id="bntEditarEmpresa" class="button button-rounded button-flat-primary button-large"> <span class="fa fa-save" style="margin-right: 10px;"></span> Guardar</button>
            </section>
        </div>
        <div id="dialogNuevoUsuario">
            <p>Para poder registrar un nuevo usuario, es necesario ingresar una nueva empresa<br /></p>
            <p>¿Desea registrar una nueva empresa?</p>
            <form method="post">
                <button id="btnCancelar" name="Cancelar" value="Cancelar"  class="button button-rounded button-flat-caution button-large" style="width: 48%;"> <span class="fa fa-close" style="margin-right: 10px;"></span>No</button>
                <button name="NuevoUsuario" value="NuevoUsuario" type="submit" class="button button-rounded button-flat-action button-large" style="width:48%;"> <span class="fa fa-check" style="margin-right: 10px;"></span>Si</button>
            </form>
        </div>
        <?php
        include_once '../plantilla/footer.php';
        ?>
        
    </body>
</html>