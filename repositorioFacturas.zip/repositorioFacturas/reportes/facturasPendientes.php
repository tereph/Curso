<?php
include_once '../conexion/conexion.php';
function facturas() {
    if (($_POST['mes']) != 0) {
        $_POST['mes'] = $_POST['mes'] + 1;
        $query = "select f.folio,f.fecha,f.iva,f.ieps,u.idUsuario,f.nombre as factura,u.nombre,u.apellidoP,u.apellidoM,e.nombreEmpresa,
                    (select round((sum(cantidad*precioUnitario)+sum(cantidad*precioUnitario)*iva+sum(cantidad*precioUnitario)*(ieps*.10)),2) 
                    from concepto where folio=f.folio) as total
                    from factura f inner join usuario u on u.idUsuario=f.idUsuario inner join empresa e on e.idEmpresa=u.idEmpresa where f.estatus='" . $_POST['estatus'] . "' and month(fecha)='" . $_POST['mes'] . "' ";
    } else {
        //$query = "select f.folio,f.fecha,f.iva,f.ieps,u.idUsuario,f.nombre as factura,u.nombre,u.apellidoP,u.apellidoM from factura f inner join usuario u on u.idUsuario=f.idUsuario where f.estatus='" . $_POST['estatus'] . "'";
        $query = "select f.folio,f.fecha,f.iva,f.ieps,u.idUsuario,f.nombre as factura,u.nombre,u.apellidoP,u.apellidoM,e.nombreEmpresa,
                    (select round((sum(cantidad*precioUnitario)+sum(cantidad*precioUnitario)*iva+sum(cantidad*precioUnitario)*(ieps*.10)),2) 
                    from concepto where folio=f.folio) as total
                    from factura f inner join usuario u on u.idUsuario=f.idUsuario inner join empresa e on e.idEmpresa=u.idEmpresa
                    where f.estatus='" . $_POST['estatus'] . "'";
    }
    
    $result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());
    $line = mysql_fetch_array($result, MYSQL_ASSOC);
    echo '[';
    for ($i = 0; $i < mysql_num_rows($result); $i++) {
        $line['fecha'] = fn_FormatoFechas('d M Y', $line['fecha']);
        echo json_encode($line);
        if (!($i == mysql_num_rows($result) - 1)) {
            echo ",";
        }
        $line = mysql_fetch_array($result, MYSQL_ASSOC);
    }
    echo']';
}

facturas();

function fn_FormatoFechas($sFormato, $sDate) {
    $sFecha = date($sFormato, strtotime($sDate)); // formatea la fecha

    if (strpos($sFormato, 'D') !== false) {  //D traduce [Mon (Lun) hasta Sun (Dom)]
        $arrFrom = array("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun");
        $arrTo = array("Lun", "Mar", "MiÃ©", "Jue", "Vie", "SÃ¡b", "Dom");
        $sFecha = str_replace($arrFrom, $arrTo, $sFecha);
    }

    if (strpos($sFormato, 'l') !== false) {  //l traduce [Monday (Lunes) hasta Sunday (Domingo)]
        $arrFrom = array("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");
        $arrTo = array("Lunes", "Martes", "MiÃ©rcoles", "Jueves", "Viernes", "SÃ¡bado", "Domingo");
        $sFecha = str_replace($arrFrom, $arrTo, $sFecha);
    }

    if (strpos($sFormato, 'M') !== false) {  //M traduce a [Jan (Ene) hasta Dec (Dic)]
        $arrFrom = array("Jan", "Apr", "Aug", "Dec");
        $arrTo = array("Ene", "Abr", "Ago", "Dic");
        $sFecha = str_replace($arrFrom, $arrTo, $sFecha);
    }

    if (strpos($sFormato, 'F') !== false) {  //F traduce [Junuary (Enero) hasta December(Diciembre)]
        $arrFrom = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        $arrTo = array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre");
        $sFecha = str_replace($arrFrom, $arrTo, $sFecha);
    }

    return $sFecha;
}
