<?php
session_start();
include_once '../../conexion/conexion.php';
// http://regex.larsolavtorvik.com/
// Expresiones regulares (RegEx) para extraer rfc de cfd ===========
// <cfdi:Receptor rfc="XXXXXXXXXXXXX" o <Receptor rfc="XXXXXXXXXXXXX"
// obtiene XXXXXXX en arreglo[1]
$idUsuario=$_POST['idU'];
$archivo=$_POST['archivo'];
$RE_receptor = '<.*?Receptor.*?"(.*?)"';

// <cfdi:Emisor rfc="XXXXXXXXXXXXX" o <Emisor rfc="XXXXXXXXXXXXX"
// obtiene XXXXXXX en arreglo[1]
$RE_emisor = '<.*?Emisor.*?"(.*?)"';
$RE_folio = '<.*?Folio.*?"(.*?)"';

// fecha="2012-07-25T11:37:25"
// Obtiene XXXX-XX-XXTXX:XX:XX en arreglo[1]
$RE_fecha = '.*?((?:2|1)\d{3}(?:-|\/)(?:(?:0[1-9])|(?:1[0-2]))(?:-|\/)(?:(?:0[1-9])|(?:[1-2][0-9])|(?:3[0-1]))(?:T|\s)(?:(?:[0-1][0-9])|(?:2[0-3])):(?:[0-5][0-9]):(?:[0-5][0-9]))';

// <Concepto descripcion="XXXXXXXXXXX" o <cfdi:Concepto descripcion="XXXXXXXXXXXXXX"
// Obtiene XXXXXXXXX en arreglo[1]
$RE_concepto = '<.*?Concepto.*?descripcion="(.*?)".*?>';
$RE_cantidad = '<.*?Concepto.*?cantidad="(.*?)".*?>';
$RE_precio = '<.*?Concepto.*?valorUnitario="(.*?)".*?>';
$RE_iva = '<.*?Traslado.*?tasa="(.*?)".*?>';
// ==================================================================
// Leer XML completo a una cadena de caracteres
// (la factura de ejemplo no tiene informacion real,
// y probablemente no sea valida por no tener sello etc.,
// pero por motivos practicos contiene la informacion que
// le interesa a nuestro algoritmo de extraccion)
//$xmlCont = file_get_contents("../uploads/Fact L217 rentas andres.xml");
//$xmlCont = file_get_contents("../uploads/".$_POST['archivo'].".xml");
$xmlCont = file_get_contents("../uploads/".$archivo.".xml");

//Extraer fecha del xml
preg_match_all("/" . $RE_fecha . "/is", $xmlCont, $matches);
$fechaxmlunix = strtotime($matches[1][0]);
$fechaxmlorig = $matches[1][0];
unset($matches);

//Extraer rfc del receptor
preg_match_all('/' . $RE_receptor . '/is', $xmlCont, $matches);
$rfcxmlre = $matches[1][0]; // RFC del receptor
unset($matches);

preg_match_all('/' . $RE_folio . '/is', $xmlCont, $matches);
$folioxmlre = $matches[1][0]; // RFC del receptor
unset($matches);

//Extraer rfc del emisor
preg_match_all('/' . $RE_emisor . '/is', $xmlCont, $matches);
$rfcxmlem = $matches[1][0]; // RFC del receptor
unset($matches);

//Extraer descripcion
preg_match_all('/' . $RE_concepto . '/is', $xmlCont, $matches);
$desxml = implode(", ", $matches[1]); // Descripciones de los conceptos separadas por coma

foreach ($matches[1] as $valor) {
    echo 'des: ' . $valor . '<br />';
}
unset($matches);

preg_match_all('/' . $RE_cantidad . '/is', $xmlCont, $matches);
$canxml = implode(", ", $matches[1]); // Descripciones de los conceptos separadas por coma

foreach ($matches[1] as $valor) {
    echo 'can: ' . $valor . '<br />';
}
unset($matches);

preg_match_all('/' . $RE_precio . '/is', $xmlCont, $matches);
$prexml = implode(", ", $matches[1]); // Descripciones de los conceptos separadas por coma
foreach ($matches[1] as $valor) {
    echo 'precio: ' . $valor . '<br />';
}
unset($matches);
preg_match_all('/' . $RE_iva . '/is', $xmlCont, $matches);
$ivaxml = implode(", ", $matches[1]); // Descripciones de los conceptos separadas por coma
echo 'iva: ' . $ivaxml . '<br />';
unset($matches);

echo "Fecha es: " . $fechaxmlorig . "<br />";
echo "Fecha UNIX es: " . $fechaxmlunix . "<br />";
echo "RFC receptor es: " . $rfcxmlre . "<br />";
echo "RFC emisor es: " . $rfcxmlem . "<br />";
echo "Conceptos: " . $desxml . "<br />";
echo "Folio: " . $folioxmlre . "<br />";

//Esto es para guardar los conceptos en un arreglo
preg_match_all('/' . $RE_concepto . '/is', $xmlCont, $matches);
$desxml = implode(", ", $matches[1]); // Descripciones de los conceptos separadas por coma
$ar= array();
foreach ($matches[1] as $valor) {
    array_push($ar, $valor);
}
unset($matches);
//Esto es para guardar la cantidad en un arreglo
$arrayCantidad=array();
preg_match_all('/' . $RE_cantidad . '/is', $xmlCont, $matches);
$canxml = implode(", ", $matches[1]); // Descripciones de los conceptos separadas por coma

foreach ($matches[1] as $valor) {
    array_push($arrayCantidad, $valor);
}
unset($matches);

//Esto es para guardar el precio unitario de cada concepto
$arrayPrecio=array();
preg_match_all('/' . $RE_precio . '/is', $xmlCont, $matches);
$prexml = implode(", ", $matches[1]); // Descripciones de los conceptos separadas por coma
foreach ($matches[1] as $valor) {
    array_push($arrayPrecio, $valor);
}
unset($matches);

//Esto es para guardar el iva de cada factura
$arrayIva=array();
preg_match_all('/' . $RE_iva . '/is', $xmlCont, $matches);
$prexml = implode(", ", $matches[1]); // Descripciones de los conceptos separadas por coma
foreach ($matches[1] as $valor) {
    array_push($arrayIva, $valor);
}
unset($matches);

//Esto es para hacer el inset en la base de datos con la nueva factura
//$idU=$_POST['idU'];
$fecha=substr($fechaxmlorig, 0, -9);
$newFact="insert into factura(folio,estatus,fecha,iva,ieps,idUsuario,nombre) "
        . "values('".$folioxmlre."','Pendiente','".$fecha."','.$arrayIva[0].','.$arrayIva[1].','.$idUsuario.','$archivo')";
mysql_query($newFact);
print_r($newFact);
//con este ciclo recorre los arrglos generados anteriormente para sacar la informción de cada uno
//ellos y guardarlo en la base de datos
for($i=0;$i<count($ar);$i++){
    print_r('Descripción: '.$ar[$i].' cantidad: '.$arrayCantidad[$i].' precio '.$arrayPrecio[$i]);
    $con=  strval($ar[$i]);
    print_r('cade    '. $con.'<br />');
    $query="insert into concepto(concepto,cantidad,precioUnitario,folio) "
            . "values('$con','$arrayCantidad[$i]','$arrayPrecio[$i]','".$folioxmlre."')";
    mysql_query($query);
    print_r($query);
}
//copy('cena.xml', '../php/');