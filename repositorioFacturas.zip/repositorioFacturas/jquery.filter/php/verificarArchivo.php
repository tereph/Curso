<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$archivo='../uploads/'.$_POST['archivo'];
if(file_exists($archivo)){
    echo ('si');
}else{
    echo ('no');
}
//if (file_exists($nombre_fichero)) {
//    echo "El fichero $nombre_fichero existe";
//} else {
//    echo "El fichero $nombre_fichero no existe";
//}