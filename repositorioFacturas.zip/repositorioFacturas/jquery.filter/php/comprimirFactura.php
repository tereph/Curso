<?php
function descargarFactura() {
$enzipado = new ZipArchive();
	if ($enzipado->open("../temp/".$_POST['fac'].".zip", ZIPARCHIVE::CREATE )!==TRUE) {
		exit("No se pudo abrir el archivo\n");
	}
	$enzipado->addFile('../uploads/'.$_POST['fac'].'.pdf');
	$enzipado->addFile('../uploads/'.$_POST['fac'].'.xml');
	//$enzipado->addFromString('contenido.txt', 'Fue creado con addFromString');
	$enzipado->close();
	header("Content-type: application/zip");
	header("Content-Disposition: attachment; filename='../temp/".$_POST['fac'].".zip");
	header("Cache-Control: no-cache, must-revalidate");
	header("Expires: 0");
	readfile("../temp/".$_POST['fac'].".zip");
        //unlink($_POST['fac'].'.zip');
//$zip = new ZipArchive();
// 
//$filename = 'test3.zip';
// 
//if($zip->open($filename,ZIPARCHIVE::CREATE)===true) {
//        $zip->addFile('../jquery.filter/uploads/Cena tere 25 nov.pdf');
//        $zip->addFile('../jquery.filter/uploads/Cena tere 25 nov.xml');
//        $zip->close();
//        echo 'Creado '.$filename;
//}
//else {
//        echo 'Error creando '.$filename;
//}
//header("Content-type: application/octet-stream");
//header("Content-disposition: attachment; filename=test3.zip");
}
descargarFactura();
?>