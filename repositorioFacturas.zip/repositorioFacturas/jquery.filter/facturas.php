<?php
if (isset($_POST['Cancelar']) and $_POST['Cancelar'] == 'Cancelar') {
    header('Location: ../usuario/usuarios.php');
}
?>
<!DOCTYPE>
<html lang="html">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Subir Facturas</title>
        <link href="../plantilla/buttons.css" rel="stylesheet" type="text/css"/>
        <link href="../usuarios/fonts/font-awesome-4.2.0/fonts/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <!--Stylesheets-->
        <link href="css/jquery.filer.css" type="text/css" rel="stylesheet" />
        <link href="css/themes/jquery.filer-dragdropbox-theme.css" type="text/css" rel="stylesheet" />
        <!--jQuery-
        <script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
        <!--<script type="text/javascript" src="js/jquery.filer.min.js?v=1.0.5"></script>-->
        <script src="js/jquery-latest.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="js/jquery.filer.js"></script>
        <script type="text/javascript" src="js/custom.js?v=1.0.5"></script>
        <script src="../plantilla/buttons.js" type="text/javascript"></script>
        <!--[if IE]>
          <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    </head>
    <body style="background-image: url('../img/fondo.jpg');">
        <div id="content" style="box-shadow: 2px 2px 5px #848484;width: 70%;margin-left: 15%;margin-top: 5px;margin-bottom: 20px;background-color:rgba(255,255,255,0.4);">
            <h1 style="color: rgb(30, 54, 100);font-size: 3em;margin: 0.67em 0;">Subir Facturas</h1>
            <div id="divE">
                <!--<form action="./php/upload.php" method="post" enctype="multipart/form-data" id="f1">-->
                <form method="post" enctype="multipart/form-data" id="f1">
                    <input type="file" name="files[]" id="filer_input" multiple="multiple" data-jfiler-limit="2" data-jfiler-extensions="pdf,xml">
                    <button type="button" value="Cancelar" id="btnCancelarFac" class="button button-rounded button-flat-caution button-jumbo" style="height: 51.2px;margin-bottom: 30px;margin-top: 50px;"><span class="fa fa-close" style="margin-right: 10px;"></span>Cancelar</button>
                    <button type="submit" value="Submit" id="btnEnviar" class="button button-rounded button-flat-primary button-jumbo" style="height: 51.2px;margin-bottom: 30px;margin-top: 50px;margin-left: 3%;"><span class="fa fa-upload" style="margin-right: 10px;"></span>Subir Factura</button>
                </form>        
            </div>        
        </div>    
    </body>
</html>