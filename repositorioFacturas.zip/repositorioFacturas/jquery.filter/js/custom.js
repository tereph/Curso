var ruta = 'http://172.30.0.87/mario/repositorioFacturas/';
var nombreArchivo;
$(document).ready(function () {
    //Example 1
//    $('#filer_input').filer({
//        showThumbs: true
//    });
    //Example 2
    $("#btnEnviar").attr('disabled', true);
    $("#btnCancelarFac").click(function () {
        window.location = ruta + 'usuarios/usuarios.php';
    });
    function handleFileSelect(evt) {
        var files = evt.target.files; // Objeto para Lista de Archivos, en el objeto existen los datos del archivo
        //var output = [];//Creamos un arreglo para guardar todos los archivos datos en diferentes posiciones.
        var tipo1;
        var tipo2;
        var n1;
        var n2;
        if (files.length == 2) {
            for (var i = 0, f; f = files[i]; i++) {//Recorremos el objeto files para obtener los datos de cada archivo y guardarlos en el arreglo.
                if (i == 0) {
                    tipo1 = f.name.substring((f.name.length) - 4, f.name.length);
                    n1 = f.name.substring(0, (f.name.length) - 4);
                    nombreArchivo=n1;
                } else {
                    tipo2 = f.name.substring((f.name.length) - 4, f.name.length);
                    n2 = f.name.substring(0, (f.name.length) - 4);
                }
            }
            if ((tipo1 == '.pdf' & tipo2 == '.xml') || (tipo1 == '.xml' & tipo2 == '.pdf')) {
                if (n1 == n2) {
                    var contador = 0;
                    for (var i = 0, f; f = files[i]; i++) {
                        $.ajax({
                            url: ruta + 'jquery.filter/php/verificarArchivo.php',
                            data: 'archivo=' + f.name,
                            type: 'post',
                            async: false,
                            success: function (r) {
                                if (r == 'si') {
                                    alert('Esta factura ya esta ingresada');
                                    $("#con").html('');
                                    evt.stopImmediatePropagation();
                                } else if (r == 'no') {
                                    contador++;
                                }
                            }
                        });
                    }
                    if (contador > 0) {
                        $("#btnEnviar").attr('disabled', false);
                    }
                } else {
                    alert('Los archivos deben tener el mismo nombre');
                    $("#con").html('');
                    evt.stopImmediatePropagation();
                }
            } else {
                alert('Solo se permiten archivos PDF y XML');
                $("#con").html('');
                evt.stopImmediatePropagation();
            }
        } else {
            alert('Debe seleccionar 2 archivos');
            $("#con").html('');
            evt.stopImmediatePropagation();
        }
    }
    document.getElementById('filer_input').addEventListener('change', handleFileSelect, false);
    nuevo();

    $("#f1").on('submit', (function (e) {
        e.preventDefault();
        $.ajax({
            url: ruta + "jquery.filter/php/upload.php", // Url to which the request is send
            type: "POST", // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false, // The content type used when sending data to the server.
            cache: false, // To unable request pages to be cached
            processData: false, // To send DOMDocument or non processed data file it is set to false
            success: function (data)   // A function to be called if request succeeds
            {
                var idUsu=usuario();
                $.ajax({
                    url: ruta + "jquery.filter/php/leerFactura.php", // Url to which the request is send
                    type: "POST", // Type of request to be send, called as method
                    async: false,
                    data: 'idU='+idUsu+'&archivo='+nombreArchivo, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
                    success: function (data)   // A function to be called if request succeeds
                    {
                        window.location=ruta+'usuarios/usuarios.php';
                    }
                });
            }
        });
    }));
});

function nuevo() {
    $('#filer_input').filer({
        changeInput: '<div class="jFiler-input-dragDrop"><div class="jFiler-input-inner"><div class="jFiler-input-icon"><i class="icon-jfi-folder"></i></div><div class="jFiler-input-text"><h3>Clic aquí</h3> <span style="display:inline-block; margin: 15px 0">ó</span></div><a class="jFiler-input-choose-btn blue">Seleccionar Archivos</a></div></div>',
        showThumbs: true,
        theme: "dragdropbox",
        templates: {
            box: '<ul class="jFiler-items-list jFiler-items-grid"></ul>',
            item: '<li class="jFiler-item">\
                    <div class="jFiler-item-container">\
                        <div class="jFiler-item-inner">\
                            <div class="jFiler-item-thumb">\
                                <div class="jFiler-item-status"></div>\
                                <div class="jFiler-item-info">\
                                    <span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name | limitTo: 25}}</b></span>\
                                    <span class="jFiler-item-others">{{fi-size2}}</span>\
                                </div>\
                                {{fi-image}}\
                            </div>\
                            <div class="jFiler-item-assets jFiler-row">\
                                <ul class="list-inline pull-left"></ul>\
                                <ul class="list-inline pull-right">\
                                    <li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
                                </ul>\
                            </div>\
                        </div>\
                    </div>\
                </li>',
            itemAppend: '<li class="jFiler-item">\
                        <div class="jFiler-item-container">\
                            <div class="jFiler-item-inner">\
                                <div class="jFiler-item-thumb">\
                                    <div class="jFiler-item-status"></div>\
                                    <div class="jFiler-item-info">\
                                        <span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name | limitTo: 25}}</b></span>\
                                        <span class="jFiler-item-others">{{fi-size2}}</span>\
                                    </div>\
                                    {{fi-image}}\
                                </div>\
                                <div class="jFiler-item-assets jFiler-row">\
                                    <ul class="list-inline pull-left">\
                                        <li><span class="jFiler-item-others">{{fi-icon}}</span></li>\
                                    </ul>\
                                    <ul class="list-inline pull-right">\
                                        <li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
                                    </ul>\
                                </div>\
                            </div>\
                        </div>\
                    </li>',
            itemAppendToEnd: false,
            removeConfirmation: true,
            _selectors: {
                list: '.jFiler-items-list',
                item: '.jFiler-item',
                remove: '.jFiler-item-trash-action'
            },
            dragDrop: {
                dragEnter: null,
                dragLeave: null,
                drop: null
            }
        }
    });
}
function usuario() {
    var url = location.search.replace("?", "");
    var arrUrl = url.split("&");
    var re;
    for (var i = 0; i < arrUrl.length; i++) {
        var x = arrUrl[i].split("=");
        re = x[1];
    }
    return re;
}