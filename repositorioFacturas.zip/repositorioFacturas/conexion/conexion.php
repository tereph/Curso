<?php
$link = mysql_connect('localhost', 'root', 'ciet4572.')
    or die('No se pudo conectar: ' . mysql_error());
mysql_select_db('repositoriocio') or die('No se pudo seleccionar la base de datos');