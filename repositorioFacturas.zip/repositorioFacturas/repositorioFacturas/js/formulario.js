ruta = 'http://172.30.0.87/mario/repositorioFacturas/';
$(document).ready(function () {
    consultarEmpresas();
    $('#cboEmpresa').dropdown();
    $('#roles').dropdown();
    $("#btnNuevoUsuario").click(function (e) {
        var nomU = $("#txtNombreUsuario").val();
        var ap = $("#txtApellidoPaterno").val();
        var am = $("#txtApellidoMaterno").val();
        var usua = $("#txtUsuario").val();
        var pass = $("#txtContrasena").val();
        var repass = $("#txtConfiContrasena").val();
        //var rol = document.getElementById("roles").value;
        var rol = document.getElementsByName('rol')[0].value;
        //var empresa = document.getElementById("cboEmpresa").value;
        var empresa = document.getElementsByName("empre")[0].value;
        var contador = 0;
        if (nomU != '' & ap != '' & am != '' & usua != '' & pass != '' & repass != '' & empresa != -1) {
            $.ajax({
                url: ruta + 'usuarios/consultas.php',
                type: 'post',
                async: false,
                success: function (respuesta) {
                    var r = JSON.parse(respuesta);
                    var usuari = $("#txtUsuario").val();
                    for (var i = 0; i < r.length; i++) {
                        if (r[i].usuario.toLowerCase() == usuari.toLowerCase()) {
                            contador = contador + 1;
                        }
                    }
                }
            });
            if (contador == 0) {
                if (pass === repass) {
                    $.ajax({
                        url: ruta + 'usuarios/nuevoUsuario.php',
                        data: 'nu=' + nomU + '&apa=' + ap + '&ama=' + am + '&usu=' + usua + '&contra=' + pass + '&rol=' + rol + '&idEmp=' + empresa,
                        type: 'post',
                        success: function (respuesta) {
                            window.location = ruta + "usuarios/usuarios.php";
                        }
                    });
                } else {
                    $.growl.error({message: 'Las contraseñas no coinciden'});
                    $("#txtContrasena").css('border-top' ,'2px solid #FF8080');
                    $("#txtContrasena").css('border-bottom' ,'2px solid #FF8080');
                    $("#txtConfiContrasena").css('border-top' ,'2px solid #FF8080');
                $("#txtConfiContrasena").css('border-bottom' ,'2px solid #FF8080');
                    e.stopImmediatePropagation();
                }
            } else {
                $.growl.error({message: 'El usuario ' + usua + ' ya esta registrado'});
                $("#txtUsuario").css('border-top' ,'2px solid #FF8080');
                $("#txtUsuario").css('border-bottom' ,'2px solid #FF8080');
                e.stopImmediatePropagation();
            }
        } else {
            $.growl.error({message: 'Todos los campos son obligatorios'});
            //if(nomU!='' & ap !='' & am !='' & usua !='' & pass!='' & corr!='' & te!='' &em!=''){
            if (nomU == '') {
                $.growl.error({message: 'El nombre de esta vacío'});
                $("#txtNombreUsuario").css('border-top' ,'2px solid #FF8080');
                $("#txtNombreUsuario").css('border-bottom' ,'2px solid #FF8080');
            }
            if (ap == '') {
                $.growl.error({message: 'El apellido paterno esta vacio'});
                $("#txtApellidoPaterno").css('border-top' ,'2px solid #FF8080');
                $("#txtApellidoPaterno").css('border-bottom' ,'2px solid #FF8080');
            }
            if (am == '') {
                $.growl.error({message: 'El apellido materno esta vacio'});
                $("#txtApellidoMaterno").css('border-top' ,'2px solid #FF8080');
                $("#txtApellidoMaterno").css('border-bottom' ,'2px solid #FF8080');
            }
            if (pass == '') {
                $.growl.error({message: 'La contraseña esta vacia'});
                $("#txtContrasena").css('border-top' ,'2px solid #FF8080');
                $("#txtContrasena").css('border-bottom' ,'2px solid #FF8080');
            }
            if (repass == '') {
                $.growl.error({message: 'La confimación de contraseña esta vacia'});
                $("#txtConfiContrasena").css('border-top' ,'2px solid #FF8080');
                $("#txtConfiContrasena").css('border-bottom' ,'2px solid #FF8080');
                
            }
            if (usua == '') {
                $.growl.error({message: 'El usuario esta vacio'});
                $("#txtUsuario").css('border-top' ,'2px solid #FF8080');
                $("#txtUsuario").css('border-bottom' ,'2px solid #FF8080');
            }
            if (empresa == -1) {
                $.growl.error({message: 'Seleccione una empresa'});
            }
        }
    });
    $("#btnCancelarUsuario").click(function () {
        window.location = 'usuarios.php';
    });
});
function quitarError(id) {
    $("#" + id).css('border', 'none');
}
function consultarEmpresas() {
    $.ajax({
        url: ruta + 'usuarios/consultarEmpresas.php',
        data: 'tipo=' + 1,
        type: 'post',
        async: false,
        success: function (respuesta) {
            var combo = "<option value='-1' selected >Seleccione una empresa</option>";
            var r = JSON.parse(respuesta);
            for (var i = 0; i < r.length; i++) {
                combo = combo + '<option class="icon-office" name=' + r[i].idEmpresa + ' value=' + r[i].idEmpresa + '>' + r[i].nombreEmpresa + '</option>';
            }
            $("#cboEmpresa").html(combo);
        }
    });
}