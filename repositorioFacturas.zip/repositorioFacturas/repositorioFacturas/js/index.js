$(document).ready(function () {
    $("#dialogRecupararPass").dialog({
        resizable: false,
        modal: true,
        width: '400',
        title: "Recuparar contraseña",
        autoOpen: false,
        show: {
            effect: "blind",
            duration: 500
        },
        hide: {
            effect: "explode",
            duration: 500
        }
    });
$("#recPass").on('submit', (function (e) {
        e.preventDefault();
        f();
        $.ajax({
            url:"recPass.php", // Url to which the request is send
            type: "POST", // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false, // The content type used when sending data to the server.
            cache: false, // To unable request pages to be cached
            processData: false, // To send DOMDocument or non processed data file it is set to false
            success: function (data)   // A function to be called if request succeeds
            {
                if(data==='notExists'){
                    $.growl.error({message: 'El usuario no existe'});
                    $("#txtRecUser").val('');
                }else{
                    window.location='../repositorioFacturas/index.php';
                }
                $.unblockUI();
            }
        });
        $.unblockUI();
    }));  
    $("#divError").hide();
$("#formLogin").on('submit', (function (e) {
        e.preventDefault();
        f();
        $.ajax({
            url:"usuarios/login.php", // Url to which the request is send
            type: "POST", // Type of request to be send, called as method
            data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
            contentType: false, // The content type used when sending data to the server.
            cache: false, // To unable request pages to be cached
            processData: false, // To send DOMDocument or non processed data file it is set to false
            success: function (data)   // A function to be called if request succeeds
            {
                if(data==1){
                    $("#divError").html('Error de usuario o contraseña');
                    $("#divError").show(1000);
                }else if(data==2){
                    window.location='../repositorioFacturas/acciones.php';
                }else if(data==3){
                    window.location='../repositorioFacturas/facturas/verFacturasPorUsuario.php';
                }else if(data==4){
                    window.location='../repositorioFacturas/usuarios/cambiarContrasena.php';    
                }
            }
        });
        $.unblockUI();
    }));    
});
function f(){
    $.blockUI();
        $.blockUI({ message: '<h2>Espere un momento<img src="../repositorioFacturas/img/716.gif" style="width:30%;" /></h2> </ br> <h3>Enviando datos...</h3>' });
}
function recuperarPass(){
    $("#dialogRecupararPass").dialog('open');
}
