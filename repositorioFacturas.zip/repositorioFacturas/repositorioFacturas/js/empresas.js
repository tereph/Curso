ruta = 'http://172.30.0.87/mario/repositorioFacturas/';
var gIdUsuarioE;
var idEmp;
$(document).ready(function () {
    $("#btnAgregarEmpresa").click(function () {
        agregarEmpresa(1, 0);
    });
    $("#dialogEmpresa").dialog({
        resizable: false,
        modal: true,
        width: '33%',
        title: "Empresas",
        autoOpen: false,
        show: {
            effect: "blind",
            duration: 500
        },
        hide: {
            effect: "explode",
            duration: 500
        }
    });
    $("#dialogEliminarEmpresa").dialog({
        resizable: false,
        modal: true,
        width: '30%',
        title: "Empresas",
        autoOpen: false,
        show: {
            effect: "blind",
            duration: 500
        },
        hide: {
            effect: "explode",
            duration: 500
        }
    });
    empresas();
    $("#bntEditarEmpresa").click(function () {
        agregarEmpresa(0, idEmp);
    });
    $("#btnCancelarEmpresa").click(function () {
        $("#dialogEmpresa").dialog('close');
        $("#frmEditarEmpresa")[0].reset();
    });
    $("#btnCerrar").click(function (){
        $("#dialogEliminarEmpresa").dialog('close');
    });
});
function agregarEmpresa(edi, id) {
    var ne = $("#txtEmpresa").val();
    var c = $("#txtCorreo").val();
    var t = $("#txtTelefono").val();
    if (ne != '' & c != '' & t != '') {
        $.ajax({
            url: ruta + 'usuarios/nuevaEmpresa.php',
            data: 'nomE=' + ne + '&co=' + c + '&te=' + t + '&editar=' + edi + '&id=' + id,
            type: 'post',
            success: function (respuesta) {
                var r = JSON.parse(respuesta);
                if (r == "3") {
                    $.growl.notice({message: 'Empresa registrada exitosamente'});
                    window.location = ruta + "usuarios/usuarios.php";
                } else if (r == "2") {
                    $.growl.notice({message: 'Empresa actualizada exitosamente'});
                    $("#dialogEmpresa").dialog('close');
                    $("#frmEditarEmpresa")[0].reset();
                    empresas();
                } else if (r == "1") {
                    $.growl.error({message: 'La empresa ' + ne + ' ya esta registrada'});
                    $("#txtEmpresa").css('border-top' ,'2px solid #FF8080');
                $("#txtEmpresa").css('border-bottom' ,'2px solid #FF8080');
                }

            }
        });
    } else {
        if (ne == '') {
            $.growl.error({message: 'El nombre de esta vacío'});
            $("#txtEmpresa").css('border-top' ,'2px solid #FF8080');
            $("#txtEmpresa").css('border-bottom' ,'2px solid #FF8080');
        }
        if (c == '') {
            $.growl.error({message: 'El correo esta vacío'});
            $("#txtCorreo").css('border-top' ,'2px solid #FF8080');
                $("#txtCorreo").css('border-bottom' ,'2px solid #FF8080');
        }
        if (t == '') {
            $.growl.error({message: 'El teléfono esta vacío'});
            $("#txtTelefono").css('border-top' ,'2px solid #FF8080');
                $("#txtTelefono").css('border-bottom' ,'2px solid #FF8080');
        }
    }
}
function quitarError(id) {
    $("#" + id).css('border', 'none');
}
function empresas() {
    $("#tblUsuarioEmpresas").html('');
    $.ajax({
        url: ruta + 'usuarios/consultas.php',
        type: 'post',
        success: function (respuesta) {
            var tabla = '<table class="table1" style="width:100%;" id="tblEmpresas"><thead><tr><th style="width:20%;">Empresa</th><th style="width:20%;">Correo</th><th style="width:15%;">Teléfono</th><th style="width:20%;">Contacto</th><th style="width:25%;">Acciones</th></tr></thead>\n\
                        <tbody>';
            var r = JSON.parse(respuesta);
            for (var i = 0; i < r.length; i++) {
                tabla = tabla + '<tr><td id="ner' + r[i].idEmpresa + '">' + r[i].nombreEmpresa + '</td>\n\
                            <td id ="c' + r[i].idEmpresa + '">' + r[i].correo + '</td>\n\
                            <td id="t' + r[i].idEmpresa + '">' + r[i].telefono + '</td>\n\
                            <td>' + r[i].nombre + ' ' + r[i].apellidoP + '</td>\n\
                            <td><a class="editarEmpresa" id="' + r[i].idEmpresa + '" style="cursor:pointer;" title="Editar Empresa"><img src="../img/edit-user.png" class="movimiento" style="cursor:pointer" onmouseover="this.width=50;this.height=40;" onmouseout="this.width=40;this.height=30;" width="40" height="30"></a>\n\
                            <a class="eliminarEmpresa" id="' + r[i].idUsuario + '"  style="cursor:pointer;" title="Eliminar Empresa"><img src="../img/delete-icon-md.png" class="movimiento" style="cursor:pointer" onmouseover="this.width=50;this.height=40;" onmouseout="this.width=40;this.height=30;" width="40" height="30"></a>\n\
                            <a title="Subir factura" class="subirFactura" id="'+r[i].idUsuario+'"><img class="movimiento" style="cursor:pointer" onmouseover="this.width=50;this.height=40;" onmouseout="this.width=40;this.height=30;" width="40" height="30" src="../img/Upload_Document.png"></a></td></tr>';
            }
            tabla = tabla + '</tbody> </table>';
            $("#tblUsuarioEmpresas").append(tabla);
//            $("#tblEmpresas").DataTable({
//                "language": {
//                    "sProcessing": "Procesando...",
//                    "sLengthMenu": "Mostrar _MENU_ registros",
//                    "sZeroRecords": "No se encontraron resultados",
//                    "sEmptyTable": "Ningún dato disponible en esta tabla",
//                    "sInfo": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
//                    "sInfoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
//                    "sInfoFiltered": "(filtrado de un total de _MAX_ registros)",
//                    "sInfoPostFix": "",
//                    "sSearch": "Buscar:",
//                    "sUrl": "",
//                    "sInfoThousands": ",",
//                    "sLoadingRecords": "Cargando...",
//                    "oPaginate": {
//                        "sFirst": "Primero",
//                        "sLast": "Último",
//                        "sNext": "Siguiente",
//                        "sPrevious": "Anterior"
//                    },
//                    "oAria": {
//                        "sSortAscending": ": Activar para ordenar la columna de manera ascendente",
//                        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
//                    }
//                },
//                "responsive": true
//            });
        }
    });
}
$(function () {
    $(document).on('click', '.editarEmpresa', function (e) {
        var idE = e.currentTarget.getAttribute("id");
        idEmp = idE;
        $("#txtEmpresa").val($("#ner" + idE).text());
        $("#txtCorreo").val($("#c" + idE).text());
        $("#txtTelefono").val($("#t" + idE).text());
        $("#dialogEmpresa").dialog('open');
    });
});
$(function () {
    $(document).on('click', '.eliminarEmpresa', function (e) {
        var idE = e.currentTarget.getAttribute("id");
        gIdUsuarioE=idE;
         $("#lblEliminarEmpresa").html('¿Esta seguro que desea eliminar la empresa '+$("#ner" + idE).text()+'?');
        $("#btnCerrar").html('<span class="fa fa-close" style="margin-right: 10px;"></span>No');
        $("#dialogEliminarEmpresa").dialog('open');
    });
});
function eliminarEmpresa(){
    $.ajax({
        url: ruta + 'usuarios/eliminarEmpresa.php',
        data: 'idUsuario=' + gIdUsuarioE,
        type: 'post',
        success: function (respuesta) {
            var r = JSON.parse(respuesta);
            if (r == 1) {
                $("#lblEliminarEmpresa").html('Lo sentimos pero no se puede eliminar esta empresa ya que tiene facturas pendientes de pago');
                $("#btnCerrar").html('<span class="fa fa-close" style="margin-right: 10px;"></span>Aceptar');
                $("#dialogEliminarEmpresa").dialog('open');
                $("#btnSiEliEmp").hide();
            } else {
                $("#dialogEliminarEmpresa").dialog('close');
                $("#btnCerrar").val('Aceptar');
                $.growl.notice({message: 'Empresa eliminada'});
                usuarios();
                empresas();
            }
        }
    });
}