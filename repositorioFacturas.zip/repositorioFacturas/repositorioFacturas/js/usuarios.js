ruta = 'http://172.30.0.87/mario/repositorioFacturas/';
var gIdUsuario;
$(document).ready(function () {
    usuarios();
    $("#btnCancelarUsuario").click(function () {
        $("#frmUsuarios")[0].reset();
        $(".txt").removeAttr('readonly');
        $("#roles").removeAttr("disabled");
        $("#dialogUsuarios").dialog('close');
    });
    $(function () {
        var icons = {
            header: "ui-icon-circle-arrow-e",
            activeHeader: "ui-icon-circle-arrow-s"
        };
        $("#accordion").accordion({
            icons: icons,
            heightStyle: "content",
            collapsible: true
        });
    });
    $("#dialogUsuarios").dialog({
        resizable: false,
        modal: true,
        width: '62%',
        title: "Editar usuario",
        autoOpen: false,
        show: {
            effect: "blind",
            duration: 500
        },
        hide: {
            effect: "explode",
            duration: 500
        }
    });
    $("#lblMensajeError").hide();
    $("#btnGuardarUsuario").click(function () {
        var id = $("#txtIdUsuario").val();
        var nomU = $("#txtNombreUsuario").val();
        var ap = $("#txtApellidoPaterno").val();
        var am = $("#txtApellidoMaterno").val();
        var pass = $("#txtContrasena").val();
        if (nomU !== '' & ap !== '' & am !== '') {
            $.ajax({
                url: ruta + 'usuarios/editarUsuario.php',
                data: 'idUsuario=' + id + '&nu=' + nomU + '&apa=' + ap + '&ama=' + am + '&contra=' + pass,
                type: 'post',
                success: function (respuesta) {
                    location.reload(true);
                }
            });
        } else {
            if (nomU == '') {
                $.growl.error({message: 'El nombre de esta vacío'});
                $("#txtNombreUsuario").css('border-top' ,'2px solid #FF8080');
                $("#txtNombreUsuario").css('border-bottom' ,'2px solid #FF8080');
            }
            if (ap == '') {
                $.growl.error({message: 'El apellido paterno esta vacio'});
                $("#txtApellidoPaterno").css('border-top' ,'2px solid #FF8080');
                $("#txtApellidoPaterno").css('border-bottom' ,'2px solid #FF8080');
            }
            if (am == '') {
                $.growl.error({message: 'El apellido materno esta vacio'});
                $("#txtApellidoMaterno").css('border-top' ,'2px solid #FF8080');
                $("#txtApellidoMaterno").css('border-bottom' ,'2px solid #FF8080');
            }
        }
    });
    $("#btnCerrarDialog").click(function () {
        $("#dialogElininarUsua").dialog('close');
    });
});
function quitarError(id) {
    $("#" + id).css('border', 'none');
}
function usuarios() {
    $("#tblUsuarioRegistrados").html('');
    $.ajax({
        url: ruta + 'usuarios/consultas.php',
        type: 'post',
        success: function (respuesta) {
            var tabla = '<table class="table1" id="tblUsuarios"><thead><tr><th scope="col">Nombre</th><th scope="col" style="display:none;"></th><th scope="col" style="display:none;"></th><th scope="col" style="display:none;"></th><th scope="col">Usuario</th><th scope="col">Empresa</th><th scope="col" style="display:none;">EstatusPass</th><th scope="col">Rol</th><th scope="col">Acciones</th></tr></thead>\n\
                        <tbody>';
            var r = JSON.parse(respuesta);
            for (var i = 0; i < r.length; i++) {
                tabla = tabla + '<tr><td id="n' + r[i].idUsuario + '">' + r[i].nombre + ' ' + r[i].apellidoP + ' ' + r[i].apellidoM + '</td>\n\
                            <td style="display:none;" id ="ap' + r[i].idUsuario + '">' + r[i].apellidoP + '</td>\n\
                            <td style="display:none;" id="am' + r[i].idUsuario + '">' + r[i].apellidoM + '</td>\n\
                            <td style="display:none;" id="name' + r[i].idUsuario + '">' + r[i].nombre + '</td>\n\
                            <td id="u' + r[i].idUsuario + '">' + r[i].usuario + '</td>\n\
                            <td id="e' + r[i].idUsuario + '">' + r[i].nombreEmpresa + '</td>\n\
                            <td style="display:none;" id="ec' + r[i].idUsuario + '">' + r[i].estatusContrasena + '</td>\n\
                            <td id="nr' + r[i].idUsuario + '">' + r[i].nombreRol + '</td>\n\
                            <td><a class="editarUsuario" id="' + r[i].idUsuario + '" style="cursor:pointer;" title="Editar Usuario"><img src="../img/edit-user.png" class="movimiento" style="cursor:pointer" onmouseover="this.width=50;this.height=40;" onmouseout="this.width=40;this.height=30;" width="40" height="30"></a>\n\
                            <a title="Subir factura" class="subirFactura" id="'+r[i].idUsuario+'"><img class="movimiento" style="cursor:pointer" onmouseover="this.width=50;this.height=40;" onmouseout="this.width=40;this.height=30;" width="40" height="30" src="../img/Upload_Document.png"></a>\n\
                            <a title="Consultar facturas de ' + r[i].nombre + ' ' + r[i].apellidoP + '" class="verFacturas" id="'+r[i].idUsuario+'"><img class="movimiento" style="cursor:pointer" onmouseover="this.width=50;this.height=40;" onmouseout="this.width=40;this.height=30;" width="40" height="30"" onmouseout="this.width=50;this.height=40;" width="50" height="40" src="../img/documents.ico"></a></td></tr>';
            }
            tabla = tabla + '</tbody> </table>';
            $("#tblUsuarioRegistrados").append(tabla);
        }
    });
}
$(function () {
    $(document).on('click', '.verFacturas', function (e) {
        var idU = e.currentTarget.getAttribute("id");
        location.href=ruta+"facturas/verFacturasPorUsuario.php?u="+idU+"";
    });
});
$(function () {
    $(document).on('click', '.subirFactura', function (e) {
        var idU = e.currentTarget.getAttribute("id");
        location.href=ruta+"jquery.filter/facturas.php?u="+idU+"";
    });
});
$(function () {
    $(document).on('click', '.editarUsuario', function (e) {
        var idU = e.currentTarget.getAttribute("id");
        $(".txt").removeAttr('readonly');
        $("#txtUsuario").attr('readonly', 'readonly');
        $("#txtEmpresa").attr('readonly', 'readonly');
        $("#btnGuardarUsuario").show();
        $("#btnNuevoUsuario").hide();
        if ($("#ec" + idU).text() == 0) {
            $("#lblMensajeError").show();
            $("#txtIdUsuario").val(idU);
            $("#txtNombreUsuario").val($("#name" + idU).text());
            $("#txtApellidoPaterno").val($("#ap" + idU).text());
            $("#txtApellidoMaterno").val($("#am" + idU).text());
            $("#txtUsuario").val($("#u" + idU).text());
            $("select#roles").val($("#nr" + idU).text());
            $("#roles").attr("disabled", "disabled");
            $(".txt").attr('readonly', 'readonly');
            $("#btnGuardarUsuario").hide();
            $("#dialogUsuarios").dialog('open');
        } else {
            $("#lblMensajeError").hide();
            $("#txtIdUsuario").val(idU);
            $("#txtNombreUsuario").val($("#name" + idU).text());
            $("#txtApellidoPaterno").val($("#ap" + idU).text());
            $("#txtApellidoMaterno").val($("#am" + idU).text());
            $("#txtUsuario").val($("#u" + idU).text());
            $("select#roles").val($("#nr" + idU).text());
            $("#roles").attr("disabled", "disabled");
            $("#dialogUsuarios").dialog('open');
        }
    });
});
