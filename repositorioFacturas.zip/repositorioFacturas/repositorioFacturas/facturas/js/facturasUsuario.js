/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var ruta = 'http://172.30.0.87/mario/repositorioFacturas/';
var usu = usuario();
if (usu == undefined) {
    usu = 0;
}
$(document).ready(function () {
    facturasPendientes();
    facturasPagadas();
    facturasCanceladas();
});
function facturasPagadas() {
    var contenido = "<div><h1>Facturas Pagadas</h1></div>";
    var ieps;
    var iva;
    var totalGeneral = 0;
    $("#tab-content2").html('');
    $.ajax({
        url: '../facturas/facturasPorUsuario.php',
        data: 'idU=' + usu + '&estatus=Pagada',
        type: 'post',
        async: false,
        success: function (respuesta) {
            var r = JSON.parse(respuesta);
            if (r.length > 0) {

                for (var i = 0; i < r.length; i++) {
                    if (r[i].ieps !== 0) {
                        ieps = parseFloat(r[i].ieps);
                    } else {
                        ieps = 0;
                    }
                    iva = parseFloat(r[i].iva);
                    if (usu != 0) {
                        contenido = contenido + '<div><h3> Folio ' + r[i].folio + ' </h3><div>' + r[i].fecha + '</div></div>';
                    } else {
                        contenido = contenido + '<div><div><h3> Folio ' + r[i].folio + ' </h3></div><div style="color:black;font-size:20px;float:left;margin-left:40%;">' + r[i].fecha + '</div><div style="float:right;"><img src="../facturas/images/download-zip.png" name="' + r[i].factura + '" onmouseover="this.width=70;this.height=60;" onmouseout="this.width=50;this.height=40;" width="50" height="40" class="movimiento" style="cursor:pointer"></div></div>';
                    }
                    $.ajax({
                        url: '../facturas/conceptos.php',
                        data: 'folio=' + r[i].folio,
                        type: 'post',
                        async: false,
                        success: function (respuest) {
                            var re = JSON.parse(respuest);
                            var subtotal = 0;
                            var total = 0;
                            contenido = contenido + '<p><table style="width:100%;text-align:center;"><thead><tr><th>Cantidad</th><th>Conceptos</th><th>Valor </th><th>Importe</th></tr></thead><tbody>';
                            for (var i = 0; i < re.length; i++) {
                                var importe = parseFloat(re[i].cantidad) * parseFloat(re[i].precioUnitario);
                                contenido = contenido + '<tr><td>' + re[i].cantidad + '</td>\n\
                            <td>' + re[i].concepto + '</td>\n\
                            <td>' + re[i].precioUnitario + '</td>\n\
                            <td>' + importe + '</td></tr>';
                                subtotal = subtotal + importe;
                            }
                            contenido = contenido + '<tr><th colspan=3 style="text-align:right;">SubTotal</th><th >' + subtotal + '</th></tr>';
                            if (ieps !== 0) {
                                contenido = contenido + '<tr><th colspan=3 style="text-align:right;">I.E.P.S</th><th>' + (subtotal * (ieps / 10)).toFixed(2) + '</th></tr>';
                            }
                            total = parseFloat(subtotal) + parseFloat((subtotal * (ieps / 10)).toFixed(2)) + parseFloat((iva * subtotal).toFixed(2));
                            total = total.toFixed(2);
                            contenido = contenido + '<tr><th colspan=3 style="text-align:right;">IVA</th><th>' + (iva * subtotal).toFixed(2) + '</th></tr>\n\
                                            <tr><th colspan=3 style="text-align:right;">Total</th><th>' + total + '</th></tr>';
                            contenido = contenido + '</tbody> </table></p><br />';
                            totalGeneral = parseFloat(totalGeneral) + parseFloat(total);
                            totalGeneral = totalGeneral.toFixed(2);
                        }
                    });
                }

            } else {
                contenido = contenido + '<div style="margin-top:30px;float:left;"><h3>No hay facturas pagadas</h3></div>';
            }
        }
    });
    $("#tab-content2").append(contenido);
}
function facturasPendientes() {
    var contenido = "";
    var ieps;
    var iva;
    var totalGeneral = 0;
    var combo;
    $("#tab-content1").html('');
    $.ajax({
        url: '../facturas/facturasPorUsuario.php',
        data: 'idU=' + usu + '&estatus=Pendiente',
        type: 'post',
        async: false,
        success: function (respuesta) {
            var r = JSON.parse(respuesta);

            contenido = contenido + '<div><h1>Facturas Pendientes</h1></div>';
            for (var i = 0; i < r.length; i++) {
                if (r[i].ieps !== 0) {
                    ieps = parseFloat(r[i].ieps);
                } else {
                    ieps = 0;
                }
                combo = "<select class='cboEstatus' name=" + r[i].folio + " id='cbo" + r[i].folio + "'>\n\
                <option disabled='disabled' selected='selected' value=0>Estatus</option>\n\
                <option value=1>Pagada</option>\n\
                <option value=2>Cancelar</option>\n\
                </select>";
                iva = parseFloat(r[i].iva);
                if (usu != 0) {
                contenido = contenido + '<div><div><h3> Folio ' + r[i].folio + ' </h3></div><div style="width:100%;"><div style="float:left;">' + combo + '</div><div style="float:left;margin-left:31%;color:black;font-size:20px;">' + r[i].fecha + '</div><div style="float:right;"><img id="' + r[i].folio + '" name="' + r[i].factura + '" class="eliminarFacturas" style="width:40px;cursor:pointer" title="Eliminar Factura" src=../images/trash-bin-open.png></div></div></div>';    
                } else {
                    contenido = contenido + '<div><h3> Folio ' + r[i].folio + ' </h3><div style="color:black;font-size:20px;float:left;margin-left:40%;">' + r[i].fecha + '</div><div style="float:right;"><img src="../facturas/images/download-zip.png" name="' + r[i].factura + '" onmouseover="this.width=70;this.height=60;" onmouseout="this.width=50;this.height=40;" width="50" height="40" class="movimiento" style="cursor:pointer" title="Descargar Factura"></div></div>';
                }
                
                $.ajax({
                    url: '../facturas/conceptos.php',
                    data: 'folio=' + r[i].folio,
                    type: 'post',
                    async: false,
                    success: function (respuest) {
                        var re = JSON.parse(respuest);
                        var subtotal = 0;
                        var total = 0;
                        contenido = contenido + '<p><table style="width:100%;text-align:center;"><thead><tr><th>Cantidad</th><th>Conceptos</th><th>Valor </th><th>Importe</th></tr></thead><tbody>';
                        for (var i = 0; i < re.length; i++) {
                            var importe = parseFloat(re[i].cantidad) * parseFloat(re[i].precioUnitario);
                            contenido = contenido + '<tr><td>' + re[i].cantidad + '</td>\n\
                            <td>' + re[i].concepto + '</td>\n\
                            <td>' + re[i].precioUnitario + '</td>\n\
                            <td>' + importe + '</td></tr>';
                            subtotal = subtotal + importe;
                        }
                        contenido = contenido + '<tr><th colspan=3 style="text-align:right;">SubTotal</th><th >' + subtotal + '</th></tr>';
                        if (ieps !== 0) {
                            contenido = contenido + '<tr><th colspan=3 style="text-align:right;">I.E.P.S</th><th>' + (subtotal * (ieps / 10)).toFixed(2) + '</th></tr>';
                        }
                        total = parseFloat(subtotal) + parseFloat((subtotal * (ieps / 10)).toFixed(2)) + parseFloat((iva * subtotal).toFixed(2));
                        total = total.toFixed(2);
                        contenido = contenido + '<tr><th colspan=3 style="text-align:right;">IVA</th><th>' + (iva * subtotal).toFixed(2) + '</th></tr>\n\
                                            <tr><th colspan=3 style="text-align:right;">Total</th><th>' + total + '</th></tr>';
                        contenido = contenido + '</tbody> </table></p> <br />';
                        totalGeneral = parseFloat(totalGeneral) + parseFloat(total);
                        totalGeneral = totalGeneral.toFixed(2);
                    }
                });
            }

        }
    });
    if (totalGeneral != 0) {
        contenido = contenido + '<div style="margin-top:30px;float:right;"><div style="float:left;padding:20px"><h3>Total a pagar:</h3></div><div style="float:left;"><h2>' + totalGeneral + '</h2></div></div>';
    } else {
        contenido = contenido + '<div style="margin-top:30px;float:left;"><h3>No hay facturas pendientes</h3></div>';
    }
    $("#tab-content1").append(contenido);
}
function facturasCanceladas() {
    var contenido = "";
    var ieps;
    var iva;
    //var i = usuario();
    var totalGeneral = 0;
    var combo;
    $("#tab-content3").html('');
    $.ajax({
        url:'../facturas/facturasPorUsuario.php',
        data: 'idU=' + usu + '&estatus=Cancelada',
        type: 'post',
        async: false,
        success: function (respuesta) {
            var r = JSON.parse(respuesta);
            contenido = contenido + '<div><h1>Facturas Canceladas</h1></div>';
            if (r.length > 0) {
                for (var i = 0; i < r.length; i++) {
                    if (r[i].ieps !== 0) {
                        ieps = parseFloat(r[i].ieps);
                    } else {
                        ieps = 0;
                    }
                    iva = parseFloat(r[i].iva);
                    contenido = contenido + '<div><div><h3> Folio ' + r[i].folio + ' </h3></div><div style="color:black;font-size:20px;margin-left:40%;">' + r[i].fecha + '</div></div>';
                    $.ajax({
                        url: '../facturas/conceptos.php',
                        data: 'folio=' + r[i].folio,
                        type: 'post',
                        async: false,
                        success: function (respuest) {
                            var re = JSON.parse(respuest);
                            var subtotal = 0;
                            var total = 0;
                            contenido = contenido + '<p><table style="width:100%;text-align:center;"><thead><tr><th>Cantidad</th><th>Conceptos</th><th>Valor </th><th>Importe</th></tr></thead><tbody>';
                            for (var i = 0; i < re.length; i++) {
                                var importe = parseFloat(re[i].cantidad) * parseFloat(re[i].precioUnitario);
                                contenido = contenido + '<tr><td>' + re[i].cantidad + '</td>\n\
                            <td>' + re[i].concepto + '</td>\n\
                            <td>' + re[i].precioUnitario + '</td>\n\
                            <td>' + importe + '</td></tr>';
                                subtotal = subtotal + importe;
                            }
                            contenido = contenido + '<tr><th colspan=3 style="text-align:right;">SubTotal</th><th >' + subtotal + '</th></tr>';
                            if (ieps !== 0) {
                                contenido = contenido + '<tr><th colspan=3 style="text-align:right;">I.E.P.S</th><th>' + (subtotal * (ieps / 10)).toFixed(2) + '</th></tr>';
                            }
                            total = parseFloat(subtotal) + parseFloat((subtotal * (ieps / 10)).toFixed(2)) + parseFloat((iva * subtotal).toFixed(2));
                            total = total.toFixed(2);
                            contenido = contenido + '<tr><th colspan=3 style="text-align:right;">IVA</th><th>' + (iva * subtotal).toFixed(2) + '</th></tr>\n\
                                            <tr><th colspan=3 style="text-align:right;">Total</th><th>' + total + '</th></tr>';
                            contenido = contenido + '</tbody> </table></p> <br />';
                            totalGeneral = parseFloat(totalGeneral) + parseFloat(total);
                            totalGeneral = totalGeneral.toFixed(2);
                        }
                    });
                }
            } else {
                contenido = contenido + '<div style="margin-top:30px;float:left;"><h3>No hay facturas canceladas</h3></div>';
            }
        }
    });
    $("#tab-content3").append(contenido);
}
$(function () {
    $(document).on('click', '.eliminarFacturas', function (e) {
        var idFa = e.currentTarget.getAttribute("id");
        var nFa = e.currentTarget.getAttribute("name");
        $.ajax({
            url:'../facturas/eliminarFactura.php',
            data: 'nF=' + nFa + '&idF=' + idFa,
            type: 'post',
            async: false,
            success: function (respuesta) {
                facturasPendientes();
                facturasPagadas();
                facturasCanceladas();
            }, error: function () {
                alert('ocurre un error al tratar de eliminar las facturas');
            }
        });
    });
});
function usuario() {
    var url = location.search.replace("?", "");
    var arrUrl = url.split("&");
    var re;
    for (var i = 0; i < arrUrl.length; i++) {
        var x = arrUrl[i].split("=");
        re = x[1];
    }
    return re;
}
$(function () {
    $(document).on('change', '.cboEstatus', function (e) {
        var cboEs = e.currentTarget.getAttribute("id");
        var nameCbo = e.currentTarget.getAttribute("name");
        var cod = document.getElementById(e.currentTarget.getAttribute("id")).value;
        var estatus;
        if (cod == 1) {
            estatus = 'Pagada';
        } else {
            estatus = 'Cancelada';
        }
        $.ajax({
            url: '../facturas/cambiarEstatusFactura.php',
            data: 'estatus=' + estatus + '&folio=' + nameCbo,
            type: 'post',
            async: false,
            success: function (respuesta) {
                facturasPendientes();
                facturasPagadas();
                facturasCanceladas();
            }, error: function () {
                alert('ocurre un error al tratar de modificar las facturas');
            }
        });
    });
});
$(function () {
    $(document).on('click', '.movimiento', function (e) {
        var factura = e.currentTarget.getAttribute("name");
        //location.href=ruta+"jquery.filter/php/comprimirFactura.php?fac="+factura+"";
        //window.location=ruta + 'jquery.filter/php/comprimirFactura.pdf';  
        $.ajax({
            url: '../jquery.filter/php/comprimirFactura.php',
            data: 'fac=' + factura,
            type: 'post',
            async: false,
            success: function (respuesta) {
                window.location = '../jquery.filter/temp/' + factura + '.zip';
            }, error: function () {
                alert('ocurre un error al tratar de descargar las facturas');
            }
        });
    });
});
