<?php
include_once '../conexion/conexion.php';
//$_POST['nF']='Cena tere 25 nov';
//$_POST['idF']="48507";
function eliminarFactura() {
    (string) $idf=$_POST['idF'];
    (string) $nF =$_POST['nF'];
    $pdf=$nF.".pdf";
    $xml=$nF.".xml";
    try {      
        $query = "delete from concepto where folio='" . $idf . "'";
        $query2 = "delete from factura where folio='" . $idf . "'";
        mysql_query($query) or die('Consulta fallida: ' . mysql_error());
        mysql_query($query2) or die('Consulta fallida: ' . mysql_error());
        unlink("../jquery.filter/uploads/$xml");
        unlink("../jquery.filter/uploads/$pdf");
    } catch (Exception $exc) {
        echo $exc->getTraceAsString();
    }
}
eliminarFactura();
