<?php

include_once '../conexion/conexion.php';
session_start();

function conceptos() {
    $query = "select * from concepto where folio=".$_POST['folio']."";
    $result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());
    $line = mysql_fetch_array($result, MYSQL_ASSOC);
    echo '[';
    for ($i = 0; $i < mysql_num_rows($result); $i++) {
        echo json_encode($line);
        if (!($i == mysql_num_rows($result) - 1)) {
            echo ",";
        }
        $line = mysql_fetch_array($result, MYSQL_ASSOC);
    }
    echo']';
}
conceptos();
