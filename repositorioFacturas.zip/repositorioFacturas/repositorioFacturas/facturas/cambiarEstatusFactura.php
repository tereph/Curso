<?php

include_once '../conexion/conexion.php';    
function cambiarEstatusFactura() {
    try {
        $query = 'update factura set estatus="' . $_POST['estatus'] . '" where folio="' . $_POST['folio'] . '"';
        mysql_query($query) or die('Consulta fallida: ' . mysql_error());
        print_r($query);
    } catch (Exception $exc) {
        echo $exc->getTraceAsString();
    }
}
cambiarEstatusFactura();
