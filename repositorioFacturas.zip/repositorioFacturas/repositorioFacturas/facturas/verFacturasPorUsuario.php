<?php
array_map('unlink', glob("../jquery.filter/temp/*.zip"));
session_start();
?>
<html>
    <head>
        <title>SCFCPC</title>
        <link href="css/style.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/css/component.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/css/demo.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/css/normalize.css" rel="stylesheet" type="text/css"/>

        <script src="../js/jquery-1.7.2.min.js" type="text/javascript"></script>
        <script src="../plantilla/js/modernizr.custom.js" type="text/javascript"></script>
        <script src="js/facturasUsuario.js" type="text/javascript"></script>
    </head>
    <body style="background-image: url('../img/fondo.jpg');background-repeat: no-repeat;background-attachment: fixed;">
        <?php
        if ($_SESSION['rol'] == 1) {
            include_once '../plantilla/menu.php';
        } else {
            include_once '../plantilla/menuUsuario.php';
        }
        ?>
        <div id="container">
            <ul class="tabs" style="width: 80%">
                <li class="labels">
                    <label for="tab1" id="label1">Facturas Pendientes</label>
                    <label for="tab2" id="label2">Facturas Pagadas</label>
                    <label for="tab3" id="label3">Facturas Canceladas</label>
                </li>
                <li>
                    <input type="radio" checked name="tabs" id="tab1">
                    <div id="tab-content1" class="tab-content" style="margin-top: 30px">
                    </div>
                </li>
                <li>
                    <input type="radio" name="tabs" id="tab2">
                    <div id="tab-content2" class="tab-content" style="margin-top: 30px">
                    </div>
                </li>
                <li>
                    <input type="radio" name="tabs" id="tab3">  
                    <div id="tab-content3" class="tab-content" style="margin-top: 30px">
                    </div>
                </li>
            </ul>  
        </div>
    </body>
</html>