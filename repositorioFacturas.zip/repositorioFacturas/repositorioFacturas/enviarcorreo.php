<?php
//setlocale (LC_TIME, "es_MX.UTF-8");
//
//$newDate=strftime("%d de %b de %Y",  strtotime($fecha));
//echo $newDate;
$fecha= '2016-04-11';
$d=fn_FormatoFechas('d M Y', $fecha);
echo 'fecha: '.$d;

/*
Nombre: fn_FormatoFechas
                Descripcion: Funcion para obtener el formato de fechas
                Entradas: $sDate (str), $sFormato (str)
                $sDate Fecha en formato ingles Y-m-d [2015-12-01]
                $sFormato puede contener los siguientes caracteres de formato:
                  d Dia del mes con 2 digitos [01 a 31],
                  j Dia del mes con 1 digito [1 a 31],
                  D Dia de la semana con 3 letras y en ingles-> traduce  [Mon (Lun) hasta Sun (Dom)]
                  l Dia de la semana con todas las letras y en ingles -> traduce  [Monday (Lunes) hasta Sunday (Domingo)]
                  F Mes con todas las letras y en ingles -> traduce  [January (Enero) hasta December (Diciembre)]
                  m Mes con 2 digitos [01 a 12]
                  n Mes con 1 digito [1 a 12]
                  M Mes con 3 letras y en ingles --> traduce  [Jan (Ene) hasta Dec (Dic)]
                  Y Anio con 4 digitos [2015]
                  y Anio con 2 digitos [78] 1978 // no recomendado a partir del 2000
                  a am o pm en minusculas
                  A AM o PM en mayusculas
                  h Horas con 1 digito [0 a 23]
                  H Horas con 2 digito [00 a 23]
                  i Minutos con 2 digito [00 a 59]
                  s Segundos con 2 digito [00 a 59]
                Letras en UTF8
                Salidas: $sFecha(str)
                *****/

                function fn_FormatoFechas($sFormato,$sDate){
                               $sFecha=date($sFormato,strtotime($sDate)); // formatea la fecha
                              
                               if(strpos($sFormato, 'D')!== false){  //D traduce [Mon (Lun) hasta Sun (Dom)]
                                               $arrFrom = array("Mon","Tue","Wed","Thu","Fri","Sat","Sun");
                                               $arrTo   = array("Lun","Mar","MiÃ©","Jue","Vie","SÃ¡b","Dom");
                                               $sFecha=str_replace($arrFrom, $arrTo, $sFecha);
                               }
                              
                               if(strpos($sFormato, 'l')!== false){  //l traduce [Monday (Lunes) hasta Sunday (Domingo)]
                                               $arrFrom = array("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday");
                                               $arrTo   = array("Lunes","Martes","MiÃ©rcoles","Jueves","Viernes","SÃ¡bado","Domingo");
                                               $sFecha=str_replace($arrFrom, $arrTo, $sFecha);
                               }
                              
                               if(strpos($sFormato, 'M')!== false){  //M traduce a [Jan (Ene) hasta Dec (Dic)]
                                               $arrFrom = array("Jan","Apr","Aug","Dec");
                                               $arrTo   = array("Ene","Abr","Ago","Dic");
                                               $sFecha=str_replace($arrFrom, $arrTo, $sFecha);
                               }
                              
                               if(strpos($sFormato, 'F')!== false){  //F traduce [Junuary (Enero) hasta December(Diciembre)]
                                               $arrFrom = array("January","February","March","April","May","June","July","August","September","October","November","December");
                                               $arrTo   = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
                                               $sFecha=str_replace($arrFrom, $arrTo, $sFecha);
                               }
                                                 
                               return $sFecha;
                }
//print_r('fecha: '.strftime("%d de %b de %Y",$fecha));
//setlocale (LC_TIME, "es_MX.UTF-8");
//
//
//$correo='huertam9876@gmail.com';
//$nombre='Mario';
//$app='Huerta';
//enviarCorreo($correo, $nombre, $app);
//function enviarCorreo($correo, $nombre, $app) {
//    $mail="<html>"
//            . "<head>Sistema de Consulta de Facturas y Cuentas por Cobrar</head>"
//            . "<body><p>Hola ".$nombre." ".$app." ha sido registrado en el Sistema de Consulta de Facturas y Cuentas por Cobrar.</p>"
//            . "<p>Lo primero que debes hacer es activar tu cuenta ingresando a la siguiente liga  con el Usuario: MarioH y la Contraseña:pass</p></body></html>";
//    //$mail = "Hola: " . $nombre . " " . $app . " has sido registrado al Sistema de Consulta de Facturas y Cuentas por Cobra \n"
//      //      . "Lo primero que debes haces hacer es ingresar a esta liga y activar tu cuenta. \r\nUsuario";
////Titulo
//    $titulo = "Sistema de Consulta de Facturas";
////cabecera
//    $headers = "MIME-Version: 1.0\r\n";
//    $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
////dirección del remitente 
//    $headers .= "From: Sistema de Facturas < huertam9876@gmail.com >\r\n";
////Enviamos el mensaje a tu_dirección_email 
//    $bool = mail("$correo", $titulo, $mail, $headers);
//    if ($bool) {
//        echo "Mensaje enviado";
//    } else {
//        echo "Mensaje no enviado";
//    }
//}
