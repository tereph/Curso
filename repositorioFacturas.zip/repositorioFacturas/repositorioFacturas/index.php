<?php
include_once './conexion/conexion.php';
session_start();
session_regenerate_id();
if (isset($_POST['Entrar'])) {
//    if (isset($_POST['user']) and isset($_POST['pass'])) {
//        $query = 'SELECT * FROM usuario where usuario="' . $_POST['user'] . '" and contrasena="' . $_POST['pass'] . '"';
//        $result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());
//        $line = mysql_fetch_array($result, MYSQL_ASSOC);
//        if (mysql_num_rows($result) > 0) {
//            if ($line['usuario'] === $_POST['user'] and $line['contrasena'] === $_POST['pass']) {
//                $_SESSION['user'] = $line['nombre'];
//                $_SESSION['usuario'] = $line['usuario'];
//                $_SESSION['pass'] = $line['contrasena'];
//                $_SESSION['rol'] = $line['idRol'];
//                $_SESSION['id'] = $line['idUsuario'];
//                $_SESSION['ec'] = $line['estatusContrasena'];
//                $_SESSION['loggedin'] = true;
//                if ($line['estatusContrasena'] == 1) {
//                    if ($_SESSION['rol'] == 1) {
//                        header('Location: acciones.php');
//                    } else {
//                        header('Location: facturas/verFacturasPorUsuario.php');
//                    }
//                } else {
//                    header('Location: usuarios/cambiarContrasena.php');
//                }
//            } else {
//                print_r('usu')    ;
//            }
//        } else {
//            print_r('pas');
//        }
//    }
}
//if (isset($_POST['Aceptar'])) {
//    $c = 'select usuario from usuario where usuario="' . $_POST['usuario'] . '"';
//    $re = mysql_query($c) or die('Consulta fallida: ' . mysql_error());
//    if (mysql_num_rows($re) > 0) {
//        $min = 1000000;
//        $max = 99999999999;
//        $newPass = mt_rand($min, $max);
//        $query = 'update usuario set estatusContrasena=0, contrasena="' . $newPass . '" where usuario ="' . $_POST['usuario'] . '"';
//        $result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());
//        $consulta = 'select e.correo from empresa e inner join usuario u on u.idEmpresa = e.idEmpresa where u.usuario="' . $_POST['usuario'] . '"';
//        $resultado = mysql_query($consulta) or die('Consulta fallida: ' . mysql_error());
//        $line = mysql_fetch_array($resultado, MYSQL_ASSOC);
//        if (mysql_num_rows($resultado) > 0) {
//            $corr = $line['correo'];
//        }
//        mysql_query($query);
//        //cambioContrasena($cor, $_POST['contra']);
//        $mail = "<html>"
//                . "<head></head>"
//                . "<body><p>Hola gracias por utilizar el Sistema de Consulta de Facturas y Cuentas por Cobrar.</p>"
//                . "<p>Le informamos que su contraseña fue reestablecida.</br>Nueva contrasena:" . $newPass . " </p></body></html>";
////Titulo
//        $titulo = "Cambio de contrasena";
////cabecera
//        $headers = "MIME-Version: 1.0\r\n";
//        $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
////dirección del remitente 
//        $headers .= "From: Sistema de Facturas < huertam9876@gmail.com >\r\n";
////Enviamos el mensaje a tu_dirección_email 
//        $bool = mail("$corr", $titulo, $mail, $headers);
//        if ($bool) {
//            echo "Mensaje enviado";
//        } else {
//            echo "Mensaje no enviado";
//        }
//    } else {
//        print_r('El usuario no existe');
//    }
//}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Expires" content="0" />
        <meta http-equiv="Pragma" content="no-cache" />
        <meta charset="UTF-8">
        <title></title>
        <link href="jqueryui/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="plantilla/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="plantilla/estiloIndex.css" rel="stylesheet" type="text/css"/>
        <link href="growl/jquery.growl.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery-1.7.2.min.js" type="text/javascript"></script>
        <script src="jqueryui/jquery-ui.js" type="text/javascript"></script>
        <script src="growl/jquery.growl.js" type="text/javascript"></script>
        <script src="js/blockUI.js" type="text/javascript"></script>
        <script src="js/index.js" type="text/javascript"></script>
        
    </head>
    <body onload="history.go(+1);">        
        <div id="dialogRecupararPass">
            <div>
                <p>Podemos ayudarte a recuperar tu contraseña. Primero ingresa tu usuario, y después revisa tu correo electrónico ahí te llegará un correo con tu nueva contraseña. </br>Por seguridad, no olvides cambiar tu contraseña.</p>
            </div>
            <form method="post" id="recPass">
                <div class="group">
                    <input class="inputMaterial" type="text" required name="usuario" id="txtRecUser">
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label class="titulo">Usuario</label>
                </div>
                <input type="submit" class="success" value="Aceptar" name="Aceptar" style="margin-top: 10px;">
            </form>
        </div>
        
        <form class="login-form" id="formLogin">
                <h1>Login</h1>
                <div id="divError"></div>
                <div class="form-group ">
                    <input type="text" class="form-control" placeholder="Usuario " id="UserName" name="user" required >
                    <i class="fa fa-user"></i>
                </div>
                <div class="form-group log-status">
                    <input type="password" class="form-control" placeholder="Contraseña" id="Passwod" name="pass" required>
                    <i class="fa fa-lock"></i>
                </div>
                <a  class="link" style="cursor:pointer;" onclick="recuperarPass();">Recuperar contraseña</a>
                <button name="Entrar" type="submit" class="log-btn" >Entrar</button>
        </form>
    </body>
</html>
