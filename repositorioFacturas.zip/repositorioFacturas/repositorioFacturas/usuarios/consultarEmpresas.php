<?php
include_once '../conexion/conexion.php';
function consultarEmpresas() {
    $query = 'select * from empresa where idEmpresa not in(select idEmpresa from usuario)';
    $result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());
    $line = mysql_fetch_array($result, MYSQL_ASSOC);
    echo '[';
    for ($i = 0; $i < mysql_num_rows($result); $i++) {
        echo json_encode($line);
        if (!($i == mysql_num_rows($result) - 1)) {
            echo ",";
        }
        $line = mysql_fetch_array($result, MYSQL_ASSOC);
    }
    echo']';
}
consultarEmpresas();