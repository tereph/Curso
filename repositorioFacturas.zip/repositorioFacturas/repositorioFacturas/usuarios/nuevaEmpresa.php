<?php

include_once '../conexion/conexion.php';
 if ($_POST['editar'] == 1){
    $q = 'select * from empresa where nombreEmpresa="' . $_POST['nomE'] . '"';
    $resul = mysql_query($q) or die('Consulta fallida: ' . mysql_error());
    if (mysql_num_rows($resul) > 0) {
        echo json_encode(1);
    } else {
        $query = 'insert into empresa (nombreEmpresa,correo,telefono)
            values("' . $_POST['nomE'] . '","' . $_POST['co'] . '","' . $_POST['te'] . '")';
        $result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());
        echo json_encode(3);
    }
}
if ($_POST['editar'] == 0) {
    $query = 'update empresa set telefono="' . $_POST['te'] . '" ,correo="' . $_POST['co'] . '" where idEmpresa=' . $_POST['id'] . '';
    $result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());
    echo json_encode(2);
}