<?php
include_once '../conexion/conexion.php';
$query = 'select * from empresa where nombreEmpresa="' . $_POST['nomE'] . '"';
    $result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());
    if (mysql_num_rows($result) > 0) {
        echo json_encode(1);
    }else{
        echo json_encode(0);
    }