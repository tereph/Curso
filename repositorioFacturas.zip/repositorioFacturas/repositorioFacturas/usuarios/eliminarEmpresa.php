<?php
include_once '../conexion/conexion.php';
$query = 'select * from factura where idUsuario='.$_POST['idUsuario'].' and estatus="Pendiente"';
$result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());
if (mysql_num_rows($result) > 0) {
    echo json_encode(1);
}else{    
    $eliFac='select nombre from factura where idUsuario='.$_POST['idUsuario'].'';
    $resu = mysql_query($eliFac) or die('Consulta fallida: ' . mysql_error());
    $l = mysql_fetch_array($resu, MYSQL_ASSOC);
    for ($i = 0; $i < mysql_num_rows($resu); $i++) {
        unlink('../jquery.filter/uploads/'.$l['nombre'].'.pdf');
        unlink('../jquery.filter/uploads/'.$l['nombre'].'.xml');
    }
    $c = 'call repositoriocio.sp_eliminarEmpresa('.$_POST['idUsuario'].');';
    $r = mysql_query($c) or die('Consulta fallida: ' . mysql_error());
    echo json_encode(0);
}



    