<?php 
if (isset($_POST['Cancelar'])) {
    header('Location: ../usuarios/usuarios.php');
}
?>
<!DOCTYPE html>
<html>
    <head>
        <script src="../js/jquery-1.7.2.min.js" type="text/javascript"></script>
        <link href="../growl/jquery.growl.css" rel="stylesheet" type="text/css"/>
        <link href="css/normalize.css" rel="stylesheet" type="text/css"/>        
        <link href="css/demoEstiloCajas.css" rel="stylesheet" type="text/css"/>
        <link href="css/estiloCajas.css" rel="stylesheet" type="text/css"/>
        
        <link href="../plantilla/buttons.css" rel="stylesheet" type="text/css"/>
        <link href="fonts/font-awesome-4.2.0/fonts/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        
        <script src="../plantilla/buttons.js" type="text/javascript"></script>
        <script src="../growl/jquery.growl.js" type="text/javascript"></script>
        <script src="../js/empresas.js" type="text/javascript"></script>
    </head>
    <body style="background-image: url('../img/fondo.jpg');">
        <form method="post" style="box-shadow: 2px 2px 5px #848484;width: 70%;margin-left: 15%;margin-top: 5px;margin-bottom: 20px;background-color:rgba(255,255,255,0.4);">
            <section class="content" >
                <h1 style="color: #1e3664;">Nueva Empresa</h1>
                <span class="input input--fumi">
                    <input type="text" id="txtEmpresa" name="emp" class="input__field input__field--fumi" onfocus="quitarError('txtEmpresa');">    
                    <label class="input__label input__label--fumi" for="txtEmpresa">
                        <i class="fa fa-fw fa-building icon icon--fumi"></i>
                        <span class="input__label-content input__label-content--fumi">Nombre</span>
                    </label>
                </span>
                <span class="input input--fumi">
                    <input type="text" id="txtCorreo" name="email" class="input__field input__field--fumi" onfocus="quitarError('txtCorreo');">    
                    <label class="input__label input__label--fumi" for="txtCorreo">
                        <i class="fa fa-fw fa-envelope-o icon icon--fumi"></i>
                        <span class="input__label-content input__label-content--fumi">Correo</span>
                    </label>
                </span>
                <span class="input input--fumi">
                    <input type="text" id="txtTelefono" name="emp" class="input__field input__field--fumi" onfocus="quitarError('txtTelefono');">    
                    <label class="input__label input__label--fumi" for="txtTelefono">
                        <i class="fa fa-fw fa-fax icon icon--fumi"></i>
                        <span class="input__label-content input__label-content--fumi">Telefono</span>
                    </label>
                </span>
                <section style="text-align: right;width: 80%;margin-left: 10%;">
                    <button id="btnCancelarEmpresa" class="button button-rounded button-flat-caution button-jumbo" type="submit" value="Cancelar" name="Cancelar" style="height: 51.2px;margin-bottom: 30px;margin-top: 50px; "><span class="fa fa-close" style="margin-right: 10px;"></span> Cancelar</button>
                    <button type="button" value="Agregar" id="btnAgregarEmpresa" class="button button-rounded button-flat-primary button-jumbo" style="height: 51.2px;margin-bottom: 30px;margin-top: 50px;margin-left: 15px;"><span class="fa fa-save" style="margin-right: 10px;"></span>Guardar</button>
                </section>
            </section>
            <!--<label>Empresa</label>
            <input type="text" id="txtEmpresa" name="emp" class="txt" onkeypress="quitarError('txtEmpresa');">    
            <label>Correo</label>
            <input type="text" id="txtCorreo" name="email" class="txt" onkeypress="quitarError('txtCorreo');">    
            <label>Teléfono</label>
            <input type="text" id="txtTelefono" name="tel" class="txt" onkeypress="quitarError('txtTelefono');">
            <input type="submit" name="Cancelar" value="Cancelar">
            -->
        </form>
        <script src="js/classie.js" type="text/javascript"></script>
        <script type="text/javascript">
                        (function () {
                            // trim polyfill : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/Trim
                            if (!String.prototype.trim) {
                                (function () {
                                    // Make sure we trim BOM and NBSP
                                    var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
                                    String.prototype.trim = function () {
                                        return this.replace(rtrim, '');
                                    };
                                })();
                            }

                            [].slice.call(document.querySelectorAll('input.input__field')).forEach(function (inputEl) {
                                // in case the input is already filled..
                                if (inputEl.value.trim() !== '') {
                                    classie.add(inputEl.parentNode, 'input--filled');
                                }

                                // events:
                                inputEl.addEventListener('focus', onInputFocus);
                                inputEl.addEventListener('blur', onInputBlur);
                            });

                            function onInputFocus(ev) {
                                classie.add(ev.target.parentNode, 'input--filled');
                            }

                            function onInputBlur(ev) {
                                if (ev.target.value.trim() === '') {
                                    classie.remove(ev.target.parentNode, 'input--filled');
                                }
                            }
                        })();
        </script>
    </body>
</html>

