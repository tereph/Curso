<?php
include_once '../conexion/conexion.php';
function obtenerUsuario() {
        //$query = 'SELECT * FROM usuario where idUsuario='.$_POST['id'];
        $query = 'SELECT * FROM usuario u inner join rol r on r.idRol=u.idRol inner join empresa e on e.idEmpresa=u.idEmpresa where estatusUsuario=1 order by idUsuario desc';
        $result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());
        $line = mysql_fetch_array($result, MYSQL_ASSOC);
        echo '[';
        for($i=0;$i<mysql_num_rows($result);$i++){
            echo json_encode($line);
            if (! ($i == mysql_num_rows($result)-1)) {
                echo ",";
            }
            $line = mysql_fetch_array($result, MYSQL_ASSOC);
        }
        echo']';
}
obtenerUsuario();