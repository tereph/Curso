<?php
include_once '../conexion/conexion.php';
session_start();
if (isset($_POST['user']) and isset($_POST['pass'])) {
        $query = 'SELECT * FROM usuario where usuario="' . $_POST['user'] . '" and contrasena="' . $_POST['pass'] . '"';
        $result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());
        $line = mysql_fetch_array($result, MYSQL_ASSOC);
        if (mysql_num_rows($result) > 0) {
            if ($line['usuario'] === $_POST['user'] and $line['contrasena'] === $_POST['pass']) {
                $_SESSION['user'] = $line['nombre'];
                $_SESSION['usuario'] = $line['usuario'];
                $_SESSION['pass'] = $line['contrasena'];
                $_SESSION['rol'] = $line['idRol'];
                $_SESSION['id'] = $line['idUsuario'];
                $_SESSION['ec'] = $line['estatusContrasena'];
                $_SESSION['loggedin'] = true;
                if ($line['estatusContrasena'] == 1) {
                    if ($_SESSION['rol'] == 1) {
                        //header('Location: ../acciones.php');
                        print_r(2);
                    } else {
                        print_r(3);
                        //header('Location: facturas/verFacturasPorUsuario.php');
                    }
                } else {
                    print_r(4);
                    //header('Location: cambiarContrasena.php');
                }
            } else {
                print_r(1);
            }
        } else {
            print_r(1);
        }
    }
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

