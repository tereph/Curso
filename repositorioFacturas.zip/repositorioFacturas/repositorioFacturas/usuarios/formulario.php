<?php
?>
<!DOCTYPE html>
<html>
    <head>
        <script src="../js/jquery-1.7.2.min.js" type="text/javascript"></script>
        <!-- ESTILOS PARA LAS CAJAS DE TEXTO -->
        <link href="css/normalize.css" rel="stylesheet" type="text/css"/>
        <!--<link href="fonts/font-awesome-4.2.0/fonts/font-awesome.min.css" rel="stylesheet" type="text/css"/>-->
        <link href="css/demoEstiloCajas.css" rel="stylesheet" type="text/css"/>
        <link href="css/estiloCajas.css" rel="stylesheet" type="text/css"/>

        <!-- FIN DEL ESTILO PARA CAJAS DE TEXTO-->
        <!--ESTILO PARA LOS COMBOS-->
        <link href="css/estiloCombos.css" rel="stylesheet" type="text/css"/>
        <link href="fonts/icomoon/style.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.dropdown.js" type="text/javascript"></script>
        <script src="js/modernizr.custom.63321.js" type="text/javascript"></script>
        <!--FIN DEL ESTILO PARA LOS COMBOS -->
        
        <!-- ESTILO PARA LOS BOTONES-->
<link href="../plantilla/buttons.css" rel="stylesheet" type="text/css"/>
        <link href="fonts/font-awesome-4.2.0/fonts/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <script src="../plantilla/buttons.js" type="text/javascript"></script>
        <!-- FIN DEL ESTILO PARA LOS BOTONES-->
        <link href="../growl/jquery.growl.css" rel="stylesheet" type="text/css"/>
        <script src="../growl/jquery.growl.js" type="text/javascript"></script>
        <script src="../js/formulario.js" type="text/javascript"></script>
    </head>
    <body style="background-image: url('../img/fondo.jpg');">
        <!--<form method="post" id="agregaCli">
            <label>Nombre</label>
            <input type="text" id="txtNombreUsuario" name="nu" class="txt" onkeypress="quitarError('txtNombreUsuario');">    
            <label>Apellido Paterno</label>
            <input type="text" id="txtApellidoPaterno" name="apa" class="txt" onkeypress="quitarError('txtApellidoPaterno');">    
            <label>Apellido Materno</label>
            <input type="text" id="txtApellidoMaterno" name="ama" class="txt" onkeypress="quitarError('txtApellidoMaterno');">    
            <select id="cboEmpresa" class="txt" onchange="quitarError('cboEmpresa');">
            </select>
            <label>Usuario</label>
            <input type="text" id="txtUsuario" name="usu" class="txt" onkeypress="quitarError('txtUsuario');">
            <label>Contraseña</label>
            <input type="password" id="txtContrasena" name="contra" class="txt" onkeypress="quitarError('txtContrasena');">
            <label>Confirmar Contraseña</label>
            <input type="password" id="txtConfiContrasena" class="txt" onkeypress="quitarError('txtConfiContrasena');">    
            <label>Rol</label>
            <select id="roles" name="rol">
                <option value="2">Cliente</option>
                <option value="1">Admistrador</option>
            </select>            
            <input type="submit" value="Cancelar" name="Cancelar">
        </form>
        
        <form method="post" id="agregaCli" name="frmUsuario" style="box-shadow: 2px 2px 5px #848484;width: 70%;margin-left: 15%;margin-top: 5px;margin-bottom: 20px;background-color:rgba(255,255,255,0.4);">
        -->
        
        <div id="agregaCli" name="frmUsuario" style="box-shadow: 2px 2px 5px #848484;width: 70%;margin-left: 15%;margin-top: 5px;margin-bottom: 20px;background-color:rgba(255,255,255,0.4);">
            <section class="content" >
                <h1 style="color: #1e3664;">Nuevo Usuario</h1>
                <span class="input input--fumi">
                    <input type="text" id="txtNombreUsuario" name="nu" class="input__field input__field--fumi" required onfocus="quitarError('txtNombreUsuario');">    
                    <label class="input__label input__label--fumi" for="txtNombreUsuario">
                        <i class="fa fa-fw icon-user icon icon--fumi"></i>
                        <span class="input__label-content input__label-content--fumi">Nombre</span>
                    </label>
                </span>
                <span class="input input--fumi">
                    <input type="text" id="txtApellidoPaterno"  name="apa" class="input__field input__field--fumi" required onfocus="quitarError('txtApellidoPaterno');">    
                    <label class="input__label input__label--fumi" for="txtApellidoPaterno">
                        <i class="fa fa-fw icon-user icon icon--fumi"></i>
                        <span class="input__label-content input__label-content--fumi">Apellido Paterno</span>
                    </label>
                </span>
                <span class="input input--fumi">
                    <input type="text" id="txtApellidoMaterno" name="ama" class="input__field input__field--fumi" required onfocus="quitarError('txtApellidoMaterno');">    
                    <label class="input__label input__label--fumi" for="txtApellidoMaterno">
                        <i class="fa fa-fw icon-user icon icon--fumi"></i>
                        <span class="input__label-content input__label-content--fumi">Apellido Materno</span>
                    </label>
                </span>
                <span class="input input--fumi">
                    <input type="text" id="txtUsuario" name="usu" class="input__field input__field--fumi" required onfocus="quitarError('txtUsuario');">
                    <label class="input__label input__label--fumi" for="txtUsuario">
                        <i class="fa fa-fw icon-user2 icon icon--fumi"></i>
                        <span class="input__label-content input__label-content--fumi">Usuario</span>
                    </label>
                </span>
                <span class="input input--fumi">
                    <input type="password" id="txtContrasena" name="contra" class="input__field input__field--fumi" required onfocus="quitarError('txtContrasena');">
                    <label class="input__label input__label--fumi" for="txtContrasena" onfocus="quitarError('txtContrasena');">
                        <i class="fa fa-fw icon-lock icon icon--fumi"></i>
                        <span class="input__label-content input__label-content--fumi">Contraseña</span>
                    </label>
                </span>
                <span class="input input--fumi">
                    <input type="password" id="txtConfiContrasena" class="input__field input__field--fumi" required onfocus="quitarError('txtConfiContrasena');"> 
                    <label class="input__label input__label--fumi" for="txtConfiContrasena">
                        <i class="fa fa-fw icon-lock icon icon--fumi"></i>
                        <span class="input__label-content input__label-content--fumi">Confirmar Contraseña</span>
                    </label>
                </span>
                <table style="width: 80%;margin-left: 10%">
                    <tr><td style="width: 46%">
                            <select id="cboEmpresa" name="empre" class="cd-select">
                            </select>
                        </td>
                        <td style="width: 8%">
                        </td>
                        <td style="width: 46%">
                            <select id="roles" name="rol" class="cd-select">                
                                <option value="2" class="icon-user3">Cliente</option>
                                <option value="1" class="icon-user3">Administrador</option>
                            </select>
                        </td></tr>
                </table>
            </section>
            <section style="text-align: right;margin-right: 10%">
                <button id="btnCancelarUsuario" class="button button-rounded button-flat-caution button-jumbo" type="button" value="Cancelar" name="Cancelar" style="height: 51.2px;margin-bottom: 30px;margin-top: 50px;"><span class="fa fa-close" style="margin-right: 10px;"></span> Cancelar</button>
                <button id="btnNuevoUsuario" class="button button-rounded button-flat-primary button-jumbo" style="height: 51.2px;margin-bottom: 30px;margin-top: 50px;"><span class="fa fa-user" style="margin-right: 10px;"></span>Guardar Usuario</button>
            </section>
        </div>
        
        <script src="js/classie.js" type="text/javascript"></script>
        <script type="text/javascript">
                        (function () {
                            // trim polyfill : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/Trim
                            if (!String.prototype.trim) {
                                (function () {
                                    // Make sure we trim BOM and NBSP
                                    var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
                                    String.prototype.trim = function () {
                                        return this.replace(rtrim, '');
                                    };
                                })();
                            }

                            [].slice.call(document.querySelectorAll('input.input__field')).forEach(function (inputEl) {
                                // in case the input is already filled..
                                if (inputEl.value.trim() !== '') {
                                    classie.add(inputEl.parentNode, 'input--filled');
                                }

                                // events:
                                inputEl.addEventListener('focus', onInputFocus);
                                inputEl.addEventListener('blur', onInputBlur);
                            });

                            function onInputFocus(ev) {
                                classie.add(ev.target.parentNode, 'input--filled');
                            }

                            function onInputBlur(ev) {
                                if (ev.target.value.trim() === '') {
                                    classie.remove(ev.target.parentNode, 'input--filled');
                                }
                            }
                        })();
        </script>
    </body>
</html>