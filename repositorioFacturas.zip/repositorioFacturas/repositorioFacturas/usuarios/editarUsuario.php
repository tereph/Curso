<?php

include_once '../conexion/conexion.php';
$consult = 'select contrasena,idRol,correo from usuario u inner join empresa e on e.idEmpresa=u.idEmpresa where u.idUsuario=' . $_POST['idUsuario'] . '';
mysql_query($consult);
$resultad = mysql_query($consult) or die('Consulta fallida: ' . mysql_error());
$rol;
$cor;
while ($fila = mysql_fetch_assoc($resultad)) {
    $c = $fila['contrasena'];
    $cor = $fila['correo'];
    $rol = $fila['idRol'];
}
if (($_POST['contra']) != '') {
    $query = 'call repositoriocio.sp_nuevoUsuario(' . $_POST['idUsuario'] . ',"' . $_POST['nu'] . '","' . $_POST['apa'] . '", "' . $_POST['ama'] . '",null, "' . $_POST['contra'] . '",null,' . $rol . ')';
    mysql_query($query);
    //cambioContrasena($cor, $_POST['contra']);
    $mail = "<html>"
            . "<head></head>"
            . "<body><p>Hola gracias por utilizar el Sistema de Consulta de Facturas y Cuentas por Cobrar.</p>"
            . "<p>Le informamos que su contraseña fue reestablecida.</br>Nueva contrasena:" . $_POST['contra'] . " </p></body></html>";
//Titulo
    $titulo = "Cambio de contrasena";
//cabecera
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
//dirección del remitente 
    $headers .= "From: Sistema de Facturas < huertam9876@gmail.com >\r\n";
//Enviamos el mensaje a tu_dirección_email 
    $bool = mail("$cor", $titulo, $mail, $headers);
    if ($bool) {
        echo "Mensaje enviado";
    } else {
        echo "Mensaje no enviado";
    }
} else {
    //$query = 'call repositoriocio.sp_nuevoUsuario(' . $_POST['idUsuario'] . ',"' . $_POST['nu'] . '","' . $_POST['apa'] . '", "' . $_POST['ama'] . '",null,null,null,1)';
    $query = 'call repositoriocio.sp_nuevoUsuario(' . $_POST['idUsuario'] . ',"' . $_POST['nu'] . '","' . $_POST['apa'] . '", "' . $_POST['ama'] . '",null,null,null,' . $rol . ')';
    mysql_query($query);
}