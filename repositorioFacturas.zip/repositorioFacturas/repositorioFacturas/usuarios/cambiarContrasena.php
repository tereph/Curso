<?php
session_start();
include_once '../conexion/conexion.php';
$us = $_SESSION['id'];
if (isset($_POST['Si']) and $_POST['Si'] == 'Si') {
    $query = 'update usuario set estatusContrasena=1, contrasena="' . $_POST['newpass'] . '" where idUsuario="' . $us . '"';
    $result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());
    header('Location: ../index.php');
}
?>
<!DOCTYPE html>
<html> 
    <head title="Cambio de constraseña">
        <link href="../growl/jquery.growl.css" rel="stylesheet" type="text/css"/>
        <link href="../jqueryui/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/estiloIndex.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/estiloBotones.css" rel="stylesheet" type="text/css"/>
        <link href="fonts/font-awesome-4.2.0/fonts/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/buttons.css" rel="stylesheet" type="text/css"/>
        <script src="../js/jquery-1.7.2.min.js" type="text/javascript"></script>
        <script src="../jqueryui/jquery-ui.js" type="text/javascript"></script>
        <script src="../growl/jquery.growl.js" type="text/javascript"></script>
        <script src="../js/blockUI.js" type="text/javascript"></script>
        <script src="../plantilla/buttons.js" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready(function () {                
                $("#btnCambiarPass").click(function () {
                    var pass = $("#txtNewPass").val();
                    var repass = $("#txtRePass").val();
                    if (pass !== '' & repass !== '') {
                        if (pass === repass) {
                            $("#txtNewPasss").val(pass);
                            $("#txtRePasss").val(repass);
                            $("#dialogConfirmarC").dialog('open');
                        } else {
                            $.growl.error({message: 'Las contraseñas no coiciden'});
                            $("#txtNewPass").val('');
                            $("#txtRePass").val('');
                        }
                    } else {
                        $.growl.error({message: 'Los campos son obligatorios'});
                        
                    }
                });
                $("#btnNo").click(function () {
                    $("#frmCambiarPass")[0].reset();
                    $("#dialogConfirmarC").dialog('close');
                });
                $("#dialogConfirmarC").dialog({
                    resizable: false,
                    modal: true,
                    width: 'auto',
                    title: "Cambio de contraseña",
                    autoOpen: false,
                    show: {
                        effect: "blind",
                        duration: 500
                    },
                    hide: {
                        effect: "explode",
                        duration: 500
                    }
                });
            });
        </script>
    </head>
    <body>
        <div class="login-form" style="width: 410px;" id="changePass">
            <h1>Cambio de contraseña</h1>
            <div class="form-group ">
                <input type="password" class="form-control" id="txtNewPass" placeholder="Nueva Contraseña" required>
                    <i class="fa fa-user"></i>
            </div>
            <div class="form-group ">
                <input type="password" class="form-control" id="txtRePass" placeholder="Confirmar Contraseña" required>
                    <i class="fa fa-user"></i>
            </div>
            <button id="btnCambiarPass" class="log-btn">Aceptar</button>
            <div>
            <p>Nota:</p>
            <p>Una vez que guarde los cambios, el sistema lo redireccionará al inicio para que ingrese con su nueva contraseña.</p>
        </div>
        </div>
        
        <div id="dialogConfirmarC">
            <label>¿Esta seguro que desea guardar los cambios?</label>
            <form method="post" id="frmCambiarPass">
                <input type="hidden" id="txtNewPasss" name="newpass">
                <input type="hidden" id="txtRePasss" name="repass">
                <div style="width: 100%;margin-top: 3%;">
                    <div style="width: 47%;float: left;margin-right: 3%;">
                        <!--<a onclick="javascript:document.frmCambiarPass.submit();" href="#" class="button button-rounded button-flat-primary button-jumbo" style="width: 100%"><i class="fa fa-check" style="margin-right: 10px;"></i>SI</a>-->
                        <!--<input type="submit" name="Si" value="Si" class="primary">
                        <a class="button button-rounded button-flat-primary button-jumbo" style="height: auto;"><i class="fa fa-check" style="margin-right: 10px;"></i>si<input type="submit" name="Si" value=""></a>-->
                        <button type="submit" name="Si" value="Si" class="button button-rounded button-flat-primary" style="height: 51.2px;width: 100%;"><i class="fa fa-check" style="margin-right: 10px;"></i>SI</button>
                        
                    </div>
                    <div style="width: 47%;float: left;margin-left: 3%;">
                        <a id="btnNo" href="#" class="button button-rounded button-flat-caution button-jumbo" style="width: 100%;height: auto;"><i class="fa fa-close " style="margin-right: 10px;"></i>NO</a>
                        <!--<input type="button" value="No" id="btnNo" class="warning">-->
                    </div>
                </div>
            </form>
        </div>
    </body>
</html>

