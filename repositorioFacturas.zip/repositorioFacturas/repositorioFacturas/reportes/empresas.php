<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include_once '../conexion/conexion.php';
function empresas(){
    if(($_POST['emp']) != 0){
        $query = "select f.folio,f.fecha,f.iva,f.ieps,u.idUsuario,f.nombre as factura,u.nombre,u.apellidoP,u.apellidoM,
                    (select round((sum(cantidad*precioUnitario)+sum(cantidad*precioUnitario)*iva+sum(cantidad*precioUnitario)*(ieps*.10)),2) 
                    from concepto where folio=f.folio) as total
                    from factura f inner join usuario u on u.idUsuario=f.idUsuario where f.estatus='" . $_POST['estatus'] . "' and f.idUsuario='" . $_POST['idU'] . "' ";
    }else{
        $query='select e.nombreEmpresa,u.idUsuario
            from empresa e inner join usuario u on u.idEmpresa=e.idEmpresa;';
    }
    $result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());
    $line = mysql_fetch_array($result, MYSQL_ASSOC);
    echo '[';
    for ($i = 0; $i < mysql_num_rows($result); $i++) {
        echo json_encode($line);
        if (!($i == mysql_num_rows($result) - 1)) {
            echo ",";
        }
        $line = mysql_fetch_array($result, MYSQL_ASSOC);
    }
    echo']';
}
empresas();