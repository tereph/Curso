<?php ?>
<html>
    <head>
        <link href="css/style.css" rel="stylesheet" type="text/css"/>
        <script src="../js/jquery-1.7.2.min.js" type="text/javascript"></script>
        <link href="../plantilla/css/normalize.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/css/demo.css" rel="stylesheet" type="text/css"/>
        <link href="../plantilla/css/component.css" rel="stylesheet" type="text/css"/>
        
        <link href="../usuarios/fonts/font-awesome-4.2.0/fonts/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        
        <link href="../plantilla/buttons.css" rel="stylesheet" type="text/css"/>
        <script src="../plantilla/buttons.js" type="text/javascript"></script>
        <script src="js/reportes.js" type="text/javascript"></script>
        
        
    </head>
    <body style="background-image: url('../img/fondo.jpg');background-repeat: no-repeat;background-attachment: fixed;">
        <?php
        include_once '../plantilla/menu.php';
        ?>
        <div id="container">
            <ul class="tabs" style="width: 80%">
                <li class="labels">
                    <label for="tab1" id="label1">Todas</label>
                    <label for="tab2" id="label2">Por Empresa</label>
                    <label for="tab3" id="label3">Por Mes</label>
                </li>
                <li>
                    <input type="radio" checked name="tabs" id="tab1">
                    <div id="tab-content1" class="tab-content" style="margin-top: 30px">
                    </div>
                </li>
                <li>
                    <input type="radio" name="tabs" id="tab2">
                    <div id="tab-content2" class="tab-content" style="margin-top: 30px">
                        <div style="width: 300px;float: left">
                            <select id="cboEmpresa" name="empresa" class="form-select"></select>
                        </div>
                        <div>
                            <button id="btnBuscarEmpresa" class="button button-rounded button-flat-action button-jumbo" value="Buscar" name="Buscar" style="height: 51.2px;"><span class="fa fa-search" style="margin-right: 10px;"></span>Buscar</button>
                        </div>
                        <div id="divReporteEmpresa" style="margin-top: 30px;width: 100%">
                        </div>
                    </div>
                </li>
                <li>
                    <input type="radio" name="tabs" id="tab3">  
                    <div id="tab-content3" class="tab-content" style="margin-top: 30px">
                        <div style="width: 300px;float: left">
                            <select id="cboMes" name="mes" class="form-select"></select>
                        </div>
                        <div>
                            <button id="btnBuscar" class="button button-rounded button-flat-action button-jumbo" value="Buscar" name="Buscar" style="height: 51.2px;"><span class="fa fa-search" style="margin-right: 10px;"></span>Buscar</button>
                        </div>
                        <div id="divReporteMes" style="margin-top: 30px;width: 100%">
                        </div>
                    </div>
                </li>
            </ul>  
        </div>
        <?php
        include_once '../plantilla/footer.php';
        ?>
    </body>
</html>
