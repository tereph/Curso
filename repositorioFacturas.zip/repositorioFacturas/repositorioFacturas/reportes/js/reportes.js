/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//var ruta = 'http://localhost/repositorioFacturas/';
$(document).ready(function () {
    facturasPendientes();
    comboMes();
    //$("#cboMes").dropdown();
    $("#btnBuscar").click(function (){
        facturasPorMes();
    }); 
    $("#btnBuscarEmpresa").click(function (){
        facturasPorEmpresa();
    }); 
    $("#label3").click(function (){
        comboMes();
    });
    comboEmpresas();
});
function facturasPendientes() {
    var contenido = "<form id='frmFp'><table id='tblFp' style='width:100%'><thead><tr><th>Nombre</th><th>Fecha</th><th>Folio</th><th>Cant</th><th>Conceptos</th><th>Total</th></tr></thead><tbody>";
    var ieps;
    var iva;
    var totalGeneral = 0;
    var folio;
    var nombre;
    var fecha;
    var totalCon;
    $("#tab-content1").html('');
    $.ajax({
        url: '../reportes/facturasPendientes.php',
        data: 'estatus=Pendiente' + '&mes=0',
        type: 'post',
        async: false,
        success: function (respuesta) {
            var r = JSON.parse(respuesta);
            for (var i = 0; i < r.length; i++) {
                if (r[i].ieps !== 0) {
                    ieps = parseFloat(r[i].ieps);
                } else {
                    ieps = 0;
                }
                iva = parseFloat(r[i].iva);
                folio = r[i].folio;
                nombre = r[i].nombre + ' ' + r[i].apellidoP + ' ' + r[i].apellidoM;
                fecha = r[i].fecha;
                totalCon = r[i].total;
                $.ajax({
                    url: '../facturas/conceptos.php',
                    data: 'folio=' + r[i].folio,
                    type: 'post',
                    async: false,
                    success: function (respuest) {
                        var re = JSON.parse(respuest);
                        var subtotal = 0;
                        var total = 0;
                        contenido = contenido + '<tr><td rowspan=' + re.length + ' class="bordeDerecho">' + nombre + '</td><td rowspan=' + re.length + ' class="bordeDerecho">' + fecha + '</td><td rowspan=' + re.length + ' class="bordeDerecho">' + folio + '</td>';
                        for (var i = 0; i < re.length; i++) {
                            var importe = parseFloat(re[i].cantidad) * parseFloat(re[i].precioUnitario);

                            contenido = contenido + '<td class="bordeDerecho">' + re[i].cantidad + '</td>\n\
                            <td class="bordeDerecho">' + re[i].concepto + '</td>';
                            if (i == 0) {
                                contenido = contenido + '<td rowspan=' + re.length + '>' + totalCon + '</td>';
                            }
                            contenido = contenido + '</tr>';
                            subtotal = subtotal + importe;
                        }
                        contenido = contenido + '<tr style="background-color:#1e3664;box-shadow: 2px 2px 5px #1e3664;height:2px;"><td colspan="6"></td></tr>';
                        total = parseFloat(subtotal) + parseFloat((subtotal * (ieps / 10)).toFixed(2)) + parseFloat((iva * subtotal).toFixed(2));
                        totalGeneral = parseFloat(totalGeneral) + parseFloat(total);
                        totalGeneral = totalGeneral.toFixed(2);
                    }
                });
            }

        }
    });
    contenido = contenido + '</tbody></table></form>';
    if (totalGeneral != 0) {
        contenido = contenido + '<div style="margin-top:30px;float:right;"><div style="float:left;padding:19px;"><h3>Total:</h3></div><div style="float:right;"><h2>' + totalGeneral + '</h2></div></div>';
    } else {
        contenido = contenido + '<div style="margin-top:30px;float:left;"><h3>No hay facturas pendientes</h3></div>';
    }
    $("#tab-content1").append(contenido);
    comboMes();
}
function comboMes() {
    $("#cboMes").html('');
    var fecha = new Date();
    var mesActual = fecha.getMonth();
    var mesDos = fecha.getMonth() - 1;
    var mesTres = fecha.getMonth() - 2;
    if (mesActual == 0) {
        mesDos = fecha.getMonth() + 11;
        mesTres = 10;
    } else if (mesActual == 1) {
        mesDos = 0;
        mesTres = 11;
    }
    var mes = new Array('Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre');
    var nombreMes1 = mes[mesActual];
    var nombreMes2 = mes[mesDos];
    var nombreMes3 = mes[mesTres];
    var combo = '<option disabled="disabled" selected="selected" value=-1>Seleccione el mes</option>\n\
                <option value=' + mesActual + '>' + nombreMes1 + '</option>\n\
                <option value=' + mesDos + '>' + nombreMes2 + '</option>\n\
                <option value=' + mesTres + '>' + nombreMes3 + '</option>';
    $("#cboMes").html(combo);
}
function facturasPorMes() {
    //var mes = document.getElementById("cboMes").value;
    var mes = document.getElementsByName("mes")[0].value;
    $("#divReporteMes").html('');
    var contenidoMes = "<table style='width:100%'><thead><tr><th>Nombre</th><th>Fecha</th><th>Folio</th><th>Cant</th><th>Conceptos</th><th>Total</th></tr></thead><tbody>";
    var iepsMes;
    var ivaMes;
    var totalGeneralMes = 0;
    var folioMes;
    var nombreMes;
    var fechaMes;
    var totalConMes;
    $.ajax({
        url: '../reportes/facturasPendientes.php',
        data: 'estatus=Pendiente' + '&mes=' + mes,
        type: 'post',
        async: false,
        success: function (respuesta) {
            var rmes = JSON.parse(respuesta);
            for (var i = 0; i < rmes.length; i++) {
                if (rmes[i].ieps !== 0) {
                    iepsMes = parseFloat(rmes[i].ieps);
                } else {
                    iepsMes = 0;
                }
                ivaMes = parseFloat(rmes[i].iva);
                folioMes = rmes[i].folio;
                nombreMes = rmes[i].nombre + ' ' + rmes[i].apellidoP + ' ' + rmes[i].apellidoM;
                fechaMes = rmes[i].fecha;
                totalConMes = rmes[i].total;
                $.ajax({
                    url: '../facturas/conceptos.php',
                    data: 'folio=' + rmes[i].folio,
                    type: 'post',
                    async: false,
                    success: function (respuest) {
                        var re = JSON.parse(respuest);
                        var subtotal = 0;
                        var total = 0;
                        contenidoMes = contenidoMes + '<tr><td rowspan=' + re.length + ' class="bordeDerecho">' + nombreMes + '</td><td rowspan=' + re.length + ' class="bordeDerecho">' + fechaMes + '</td><td rowspan=' + re.length + ' class="bordeDerecho">' + folioMes + '</td>';
                        for (var i = 0; i < re.length; i++) {
                            var importe = parseFloat(re[i].cantidad) * parseFloat(re[i].precioUnitario);

                            contenidoMes = contenidoMes + '<td class="bordeDerecho">' + re[i].cantidad + '</td>\n\
                            <td class="bordeDerecho">' + re[i].concepto + '</td>';
                            if (i == 0) {
                                contenidoMes = contenidoMes + '<td rowspan=' + re.length + '>' + totalConMes + '</td>';
                            }
                            contenidoMes = contenidoMes + '</tr>';
                            subtotal = subtotal + importe;
                        }
                        contenidoMes = contenidoMes + '<tr style="background-color:#1e3664;box-shadow: 2px 2px 5px #1e3664;height:2px;"><td colspan="6"></td></tr>';
                        total = parseFloat(subtotal) + parseFloat((subtotal * (iepsMes / 10)).toFixed(2)) + parseFloat((ivaMes * subtotal).toFixed(2));
                        totalGeneralMes = parseFloat(totalGeneralMes) + parseFloat(total);
                        totalGeneralMes = totalGeneralMes.toFixed(2);
                    }
                });
            }
        }
    });
    contenidoMes = contenidoMes + '</tbody></table>';
    if (totalGeneralMes != 0) {
        contenidoMes = contenidoMes + '<div style="margin-top:30px;float:right;"><div style="float:left;padding:19px;"><h3>Total:</h3></div><div style="float:right;"><h2>' + totalGeneralMes + '</h2></div></div>';
    } else {
        var meses = new Array('Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre');
        var nombreMes = meses[mes];
        contenidoMes = '<div style="margin-top:30px;float:left;"><h3>No hay facturas pendientes para ' + nombreMes + '</h3></div>';
    }
    $("#divReporteMes").append(contenidoMes);
}
function facturasPorEmpresa() {
    //var mes = document.getElementById("cboMes").value;
    var idU = document.getElementsByName("empresa")[0].value;
    $("#divReporteEmpresa").html('');
    var contenidoMes = "<table style='width:100%'><thead><tr><th>Nombre</th><th>Fecha</th><th>Folio</th><th>Cant</th><th>Conceptos</th><th>Total</th></tr></thead><tbody>";
    var iepsMes;
    var ivaMes;
    var totalGeneralMes = 0;
    var folioMes;
    var nombreMes;
    var fechaMes;
    var totalConMes;
    $.ajax({
        url: '../reportes/empresas.php',
        data: 'estatus=Pendiente' + '&emp=2'+'&idU='+idU,
        type: 'post',
        async: false,
        success: function (respuest) {
            var rmes = JSON.parse(respuest);
            for (var i = 0; i < rmes.length; i++) {
                if (rmes[i].ieps !== 0) {
                    iepsMes = parseFloat(rmes[i].ieps);
                } else {
                    iepsMes = 0;
                }
                ivaMes = parseFloat(rmes[i].iva);
                folioMes = rmes[i].folio;
                nombreMes = rmes[i].nombre + ' ' + rmes[i].apellidoP + ' ' + rmes[i].apellidoM;
                fechaMes = rmes[i].fecha;
                totalConMes = rmes[i].total;
                $.ajax({
                    url: '../facturas/conceptos.php',
                    data: 'folio=' + rmes[i].folio,
                    type: 'post',
                    async: false,
                    success: function (respuest) {
                        var re = JSON.parse(respuest);
                        var subtotal = 0;
                        var total = 0;
                        contenidoMes = contenidoMes + '<tr><td rowspan=' + re.length + ' class="bordeDerecho">' + nombreMes + '</td><td rowspan=' + re.length + ' class="bordeDerecho">' + fechaMes + '</td><td rowspan=' + re.length + ' class="bordeDerecho">' + folioMes + '</td>';
                        for (var i = 0; i < re.length; i++) {
                            var importe = parseFloat(re[i].cantidad) * parseFloat(re[i].precioUnitario);

                            contenidoMes = contenidoMes + '<td class="bordeDerecho">' + re[i].cantidad + '</td>\n\
                            <td class="bordeDerecho">' + re[i].concepto + '</td>';
                            if (i == 0) {
                                contenidoMes = contenidoMes + '<td rowspan=' + re.length + '>' + totalConMes + '</td>';
                            }
                            contenidoMes = contenidoMes + '</tr>';
                            subtotal = subtotal + importe;
                        }
                        contenidoMes = contenidoMes + '<tr style="background-color:#1e3664;box-shadow: 2px 2px 5px #1e3664;height:2px;"><td colspan="6"></td></tr>';
                        total = parseFloat(subtotal) + parseFloat((subtotal * (iepsMes / 10)).toFixed(2)) + parseFloat((ivaMes * subtotal).toFixed(2));
                        totalGeneralMes = parseFloat(totalGeneralMes) + parseFloat(total);
                        totalGeneralMes = totalGeneralMes.toFixed(2);
                    }
                });
            }
        }
    });
    contenidoMes = contenidoMes + '</tbody></table>';
    if (totalGeneralMes != 0) {
        contenidoMes = contenidoMes + '<div style="margin-top:30px;float:right;"><div style="float:left;padding:19px;"><h3>Total:</h3></div><div style="float:right;"><h2>' + totalGeneralMes + '</h2></div></div>';
        //contenidoMes=contenidoMes+'<div><button id="btnImprimir" >Imprimir</button></div>';
    } else {
        contenidoMes = '<div style="margin-top:30px;float:left;"><h3>No hay facturas pendientes</h3></div>';
    }
    
    $("#divReporteEmpresa").append(contenidoMes);
}
function comboEmpresas(){
    $("#cboEmpresa").html('');
    $.ajax({
        url: '../reportes/empresas.php',
        data:'emp=0',
        type: 'post',
        async: false,
        success: function (respue) {
            var res=JSON.parse(respue);
            var combo = '<option disabled="disabled" selected="selected" value=-1>Seleccione la empresa</option>';
            for (var i = 0; i < res.length; i++) {
                combo=combo+'<option value=' + res[i].idUsuario + '>' + res[i].nombreEmpresa + '</option>';
            }
            
    $("#cboEmpresa").html(combo);
        }
    });
}