<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include_once './conexion/conexion.php';
session_start();
$c = 'select usuario from usuario where usuario="' . $_POST['usuario'] . '"';
    $re = mysql_query($c) or die('Consulta fallida: ' . mysql_error());
    if (mysql_num_rows($re) > 0) {
        $min = 1000000;
        $max = 99999999999;
        $newPass = mt_rand($min, $max);
        $query = 'update usuario set estatusContrasena=0, contrasena="' . $newPass . '" where usuario ="' . $_POST['usuario'] . '"';
        $result = mysql_query($query) or die('Consulta fallida: ' . mysql_error());
        $consulta = 'select e.correo from empresa e inner join usuario u on u.idEmpresa = e.idEmpresa where u.usuario="' . $_POST['usuario'] . '"';
        $resultado = mysql_query($consulta) or die('Consulta fallida: ' . mysql_error());
        $line = mysql_fetch_array($resultado, MYSQL_ASSOC);
        if (mysql_num_rows($resultado) > 0) {
            $corr = $line['correo'];
        }
        mysql_query($query);
        //cambioContrasena($cor, $_POST['contra']);
        $mail = "<html>"
                . "<head></head>"
                . "<body><p>Gracias por utilizar el Sistema de Consulta de Facturas y Cuentas por Cobrar.</p>"
                . "<p>Le informamos que su clave de acceso fue reestablecida.</ br>Nueva clave: <span style='color:#1e3664'>" . $newPass . " </span></p></body></html>";
//Titulo
        $titulo = "Cambio de contrasena";
//cabecera
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
//dirección del remitente 
        $headers .= "From: Sistema de Facturas < terep@cio.mx >\r\n";
//Enviamos el mensaje a tu_dirección_email 
        $bool = mail("$corr", $titulo, $mail, $headers);
        if ($bool) {
            echo "Mensaje enviado";
        } else {
            echo "Mensaje no enviado";
        }
    } else {
        print_r('notExists');
    }

