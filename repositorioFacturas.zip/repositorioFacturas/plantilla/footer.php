<section style="display: flex;justify-content: center;align-content: center;flex-direction: column;height: 100px;text-align: center;box-shadow: 2px 2px 5px #848484;background-color:rgba(255,255,255,0.4);
left: 0px;
bottom: 0px;
width: 100%;">
    <nav class="cl-effect-4" style="color: #1e3664;font-size: 20px;">
        Centro de Investigaciones en Óptica, S.A. 2016. Todos los derechos reservados.
    </nav>
</section>
