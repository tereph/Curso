<section style="height: 100px;box-shadow: 2px 2px 5px #848484;margin-top: 5px;margin-bottom: 20px;background-color:rgba(255,255,255,0.4);">
    <nav style="width: 12%;float: left;margin-left: 5%">
        <img src="../img/cio_logo.png" style="width: 100%">
    </nav>
    <nav class="cl-effect-4" style="margin-right: 5%;text-align: right">
        <a href="../logout.php"><span data-hover="Salir">Salir</span></a>
    </nav>
</section>
