<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    //Esto redirecciona al index
    header('Location: index.php');
}
//if (isset($_POST['Salir']) and $_POST['Salir'] == 'Salir') {
//    session_destroy();
//    header('Location: index.php');
//}
?>
<html>
    <head>
        <link href="plantilla/estiloAcciones.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div style="width: 100%;background-color:rgba(255,255,255,0.3);float: left">
            <div style="width: 10%;float: left">    
            </div>
            <div style="width: 90%;float: right">
                <div style="width: 12%;float: left">
                    <img src="img/cio_logo.png" style="width: 100%;">    
                </div>
                <div style="width: 78%;float: right;text-align: right;margin-right: 10%" class="titulo">
                    <h1>Sistema de Consulta de Facturas y Cuentas por Cobrar</h1>
                </div>
            </div>
        </div>
        <div id="divContenedor">
            <div style="width: 100%;margin-left: 17%">
                <div class="divConteAccion">
                    <a href="reportes/reportes.php">
                        <div class="acciones">
                            <div>
                                <img src="img/yellow-chart-icon.png" alt="Imagen no encontrada" title="Reportes">    
                            </div>
                            <hr style="width: 90%;color: #848484;float: left;margin-left: 5%;box-shadow: 2px 2px 5px #848484">
                            <div class="accion">
                                Reportes
                            </div>
                        </div>
                    </a>
                </div>
                <div class="divConteAccion" style="margin-left: 10%;margin-right: 10%;">
                    <a href="usuarios/usuarios.php">
                        <div class="acciones">
                            <div>
                                <img src="img/blue-user-icon.png" alt="Imagen no encontrada" title="Clientes">
                            </div>
                            <hr style="width: 90%;color: #848484;float: left;margin-left: 5%;box-shadow: 2px 2px 5px #848484">
                            <div class="accion">
                                Usuarios
                            </div>
                        </div>
                    </a>
                </div>
                <div class="divConteAccion">
                    <a href="logout.php">
                        <div class="acciones"> 
                            <div>
                                <img src="img/red-cross-icon.png" alt="Imagen no encontrada">    
                            </div>
                            <hr style="width: 90%;color: #848484;float: left;margin-left: 5%;box-shadow: 2px 2px 5px #848484">
                            <div class="accion">
                                Salir
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </body>
</html>